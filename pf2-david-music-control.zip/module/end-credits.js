/**
 * End Credits
 *
 * Rolls cinematic scrolling credits featuring all connected players.
 *
 * Usage — create a macro:
 *   game.modules.get("pf2-david-music-control").api.endCredits.toggle();
 *
 * Late-joining players: the GM's toggle persists a world setting so any client
 * that connects while credits are running will start the overlay automatically
 * on their `ready` hook. Music is handled by Foundry's own playlist sync, so
 * late-joiners hear it too without any extra work.
 */

import { MODULE_ID } from './settings.js';
const SCROLL_SPEED = 0.55;
const SOCKET_EVENT = `module.${MODULE_ID}`;

// ── Local state ────────────────────────────────────────────────────────────

let creditsActive = false;
let rafId         = null;
let posY          = 0;
let currentCreditsHtml = "";
let currentCreditsStartedAt = 0;

/**
 * Snapshot of sounds that were playing before credits started.
 * Each entry: { playlistId, soundId }
 * Stored only on the GM client; used to restore playback on stop.
 */
let pausedSnapshot = [];

function refreshSettingsToggleButton() {
  const btn = document.querySelector(`button[data-key="${MODULE_ID}.endCreditsToggle"]`);
  if (!btn) return;

  btn.innerHTML = creditsActive
    ? `<i class="fas fa-stop-circle"></i> Stop Credits`
    : `<i class="fas fa-film"></i> Start Credits`;
  btn.style.color = creditsActive ? "var(--color-level-error, #aa2222)" : "";
}

function setCreditsActive(active) {
  creditsActive = active;
  refreshSettingsToggleButton();
}

function getStoredCreditsHtml() {
  return game.settings.get(MODULE_ID, "endCreditsHtml") || "";
}

function getStoredCreditsStartedAt() {
  return Number(game.settings.get(MODULE_ID, "endCreditsStartedAt")) || 0;
}

function normalizeFolderPath(value) {
  return String(value ?? "")
    .split("/")
    .map(part => part.trim())
    .filter(Boolean)
    .join("/");
}

function getFolderPath(folder) {
  const names = [];
  let current = folder;
  while (current) {
    if (current.name) names.unshift(current.name.trim());
    current = current.folder ?? null;
  }
  return names.join("/");
}

function findActorFolderByPath(folderPath) {
  const target = normalizeFolderPath(folderPath).toLowerCase();
  if (!target) return null;

  const actorFolders = game.folders?.filter(f => f.type === "Actor") ?? [];
  return actorFolders.find(folder => {
    const path = normalizeFolderPath(getFolderPath(folder)).toLowerCase();
    return path === target || folder.name?.trim().toLowerCase() === target;
  }) ?? null;
}

function getActorsInFolderTree(folder) {
  if (!folder) return [];

  const folderIds = new Set();
  const stack = [folder];
  while (stack.length > 0) {
    const current = stack.pop();
    if (!current || folderIds.has(current.id)) continue;
    folderIds.add(current.id);
    for (const child of current.children ?? []) stack.push(child);
  }

  return game.actors?.filter(actor => folderIds.has(actor.folder?.id) && actor.type === "character") ?? [];
}

// ── Silly content ──────────────────────────────────────────────────────────

const SILLY_ROLES = [
  // Dice
  "Chief Dice Fumbler",
  "Senior Dice Blamer",
  "Director of Suspicious Dice Rolling",
  "Head of Dice Accusation",
  "Executive Dice Forgetter",
  "Natural 1 Enthusiast",
  "Dice Feng Shui Consultant",
  "Official Dice Superstition Coordinator",
  "Keeper of the Lucky Dice (That Aren't)",
  "Commissioner of Dice Rerolls That Also Failed",
  "Certified Dice Whisperer (Unverified)",
  "Head of Pre-Roll Rituals",
  "Senior Dice Blower",
  "Director of Blaming the Table",
  "Chief Dice Temperature Regulator",
  "Lead Dice Retirement Counsellor",
  "Executive Producer of Terrible Rolls",
  "Head of Rolling in Full View and Still Missing",
  "Director of Dice Jail Management",
  "Superintendent of Fumbles",

  // Rules
  "Head of Unnecessary Rule Lookups",
  "Chief Rules Lawyer (Unlicensed)",
  "Senior Rules Misrememberer",
  "Director of Citing the Wrong Edition",
  "Executive 'Actually, I Think You'll Find...'",
  "Head of Dramatic Rules Interpretations",
  "Assistant Contradictions Officer",
  "Chief 'We've Always Done It This Way' Officer",
  "Lead Condition Confusion Analyst",
  "Senior 'Let Me Just Check the Wiki' Officer",
  "Director of Making Up Rules That Sound Plausible",
  "Head of Arguing About Readied Actions",
  "Chief Adjacency Dispute Coordinator",
  "Executive Producer of Needless Rulings",
  "Keeper of the Outdated Reference Sheet",

  // Combat strategy (or lack thereof)
  "Director of Splitting the Party",
  "Senior Strategist (Retired After Round 1)",
  "Chief 'I Have a Plan' Officer (Plan Pending)",
  "Head of Charging Directly Into Traps",
  "Executive Flanking Forgetter",
  "Director of Attacking the Obviously Immune Enemy",
  "Lead 'Maybe if I Roll High Enough' Analyst",
  "Chief Overconfidence Consultant",
  "Senior Door-Kicker",
  "Head of Punching Things Until It Works",
  "Director of Standing in the Fireball",
  "Senior 'I'll Go First' Specialist (Went Last)",
  "Chief Action Economy Mismanager",
  "Lead 'Can I Intimidate It?' Researcher",
  "Executive Readied Action Forgetter",
  "Head of Accidentally Shooting Allies",
  "Director of Heroic Last Stands (Poorly Timed)",
  "Chief Tactical Retreat Denier",
  "Senior 'It Has How Many Hit Points?' Analyst",
  "Lead Overextension Coordinator",

  // Roleplay
  "Principal Character Voice Inconsistency Coordinator",
  "Head of Backstory Nobody Asked For",
  "Director of Asking NPCs Completely Off-Topic Questions",
  "Chief Intimidation Attempt Overseer (Failed)",
  "Executive Monologue Deliverer",
  "Head of In-Character Bickering",
  "Senior Dramatic Death Performance Artist",
  "Chief Unnecessary Deception Consultant",
  "Lead Accent Drifter",
  "Director of Suspiciously Convenient Backstory Reveals",
  "Head of Giving the Villain a Redemption Arc, Uninvited",
  "Chief 'My Character Would Never' Enforcement Officer",
  "Senior Dramatic Pause Coordinator",
  "Director of Speeches Nobody Asked For",
  "Lead Unnecessary Alias Creator",
  "Executive Sad Backstory Deliverer (Wrong Moment)",
  "Head of Falling in Love with Every NPC",
  "Chief Unnecessary Disguise Consultant",
  "Senior 'Actually My Character Speaks This Language' Officer",
  "Director of Unilateral Decisions That Affected Everyone",

  // Tavern and travel
  "Head of Provoking the Entire Tavern",
  "Senior Bar Tab Accumulator",
  "Chief 'Let's Ask the Locals' Coordinator",
  "Lead Unnecessary Gambling Enthusiast",
  "Director of Starting Conversations with Guards",
  "Executive 'We Should Rest Here' Officer",
  "Head of Getting Lost with a Map",
  "Senior Rations Complainer",
  "Chief 'Are We There Yet?' Correspondent",
  "Lead 'I Know a Shortcut' Navigator (Didn't)",
  "Director of Getting the Party Banned from Inns",
  "Senior 'What's the Worst That Could Happen?' Analyst",
  "Head of Buying Things Nobody Needed",
  "Executive Overencumbrance Denier",
  "Chief 'I'll Carry the Body' Volunteer",

  // Horses, animals, and pets
  "Head of Naming Horses at Length",
  "Senior Horse Abandonment Coordinator",
  "Chief Familiar Neglect Officer",
  "Director of Animal Companion Misuse",
  "Lead 'Can I Ride It?' Assessor",
  "Executive 'The Horse Is Fine' Denial Officer",
  "Head of Treating the Mount as a Character",
  "Senior Pack Mule Feelings Advocate",
  "Chief 'My Animal Would Never Bolt' Officer",

  // Loot and resources
  "Chief Loot Hoarder",
  "Head of Immediately Spending All Gold",
  "Director of Forgetting Their Spell Slots",
  "Senior Ration Counter",
  "Chief 'I Totally Have That Proficiency' Officer",
  "Executive Torch Forgetter",
  "Lead Potion Hoarder (Never Used Them)",
  "Head of Insisting the Rope Was Definitely Long Enough",
  "Director of Accidentally Selling Important Items",
  "Senior 'I'll Identify It Later' Procrastinator",
  "Chief 'We Can Come Back for It' Coordinator",
  "Lead Cursed Item Early Adopter",
  "Head of Arguing About Treasure Division",
  "Executive 'I Found It, I Keep It' Officer",
  "Senior 'How Much Is This Worth?' Appraiser (Wrong)",

  // GM interaction
  "Chief 'Can I Roll Perception?' Inquirer",
  "Senior 'What Does My Character Know About This?' Asker",
  "Head of Reading the GM's Face for Hints",
  "Director of Doing Exactly What the GM Didn't Want",
  "Executive Red Herring Chaser",
  "Lead Plot Hook Ignorer",
  "Chief Sidequester",
  "Senior 'Is This Important?' Interrogator",
  "Director of Befriending the Villain",
  "Head of Taking the Campaign Somewhere Unexpected",
  "Chief 'Was That Significant?' Asker",
  "Senior 'Can I Try Something Weird?' Applicant",
  "Director of Derailing the Carefully Planned Encounter",
  "Lead 'What If We Just...' Hypothetical Officer",
  "Executive 'The GM Seemed Nervous When I Asked' Analyst",
  "Head of Ignoring the Obvious Solution",
  "Chief 'I Thought That Guy Was a Clue' Investigator",
  "Senior Dramatic Misreading of Foreshadowing",
  "Director of Solving Problems the Long Way Round",
  "Lead 'We Should Burn It Down' Consultant",

  // Meta
  "Chief Session Note Forgetter",
  "Director of 'Wait, Didn't We Already Do This?'",
  "Senior Late Arrival Specialist",
  "Head of Phone Distractions (Combat Only)",
  "Executive 'Sorry, What Happened Last Session?' Officer",
  "Lead Character Sheet Misreader",
  "Chief 'My Backstory Has A Clause For This' Consultant",
  "Senior Bathroom Break Timer (Critical Moments Only)",
  "Director of Asking Questions Answered Two Minutes Ago",
  "Head of Falling Asleep During Exposition",
  "Chief 'Can We Wrap Up? I Have Work Tomorrow' Officer",
  "Senior 'I Thought We Were Playing Next Week' Correspondent",
  "Lead 'Should I Have Read the Module?' Self-Assessor",
  "Executive 'My Character Has Changed Since Session One' Revisionist",
  "Head of Forgetting What Level They Are",
  "Director of Re-Reading the Same Ability Three Times",
  "Chief 'I Swear It Was on My Other Sheet' Officer",
  "Senior Initiative Tracker Doubter",
  "Lead 'Can I Retcon That?' Negotiator",
  "Executive Dice Tower Misfire Specialist",
  "Head of Forgetting the Plan Mid-Sentence",
  "Chief 'Wait, I'm Still Hidden, Right?' Auditor",
  "Senior Cooldown of Tablewide Side-Eyes",
  "Director of Loudly Counting Squares Incorrectly",
  "Lead Last-Minute Spell Substitution Theorist",
];

// Crew pool — a large list we pick a random subset from each time
const CREW_POOL = [
  ["Dungeon Consultant",                  "A Very Ominous Dungeon"],
  ["Head of Monster Resources",           "An Uncooperative Dragon"],
  ["Director of Ambiance",               "That One Guttering Candle"],
  ["Chief Lore Keeper",                   "The Library of Unread Books"],
  ["Sound Design",                        "Your Collective Groaning"],
  ["Catering",                            "Whatever Was in the Bag"],
  ["Legal Counsel",                       "Arguing With the Rulebook"],
  ["Insurance",                           "Ha"],
  ["Weather Effects",                     "The GM Humming Ominously"],
  ["Animal Wrangler",                     "The Familiar No One Fed"],
  ["Continuity",                          "Nobody, Clearly"],
  ["Stunt Coordination",                  "The Fighter, Unasked"],
  ["Medical Advisor",                     "The Cleric (Eventually)"],
  ["Explosives Consultant",               "The Sorcerer, Probably"],
  ["Negotiation Coach",                   "Completely Unavailable"],
  ["Exit Strategy",                       "Still Being Workshopped"],
  ["Map Accuracy",                        "Not Guaranteed"],
  ["Torch Procurement",                   "Someone Else's Problem"],
  ["NPC Naming Department",               "Bob, Dave, and Also Bob"],
  ["Plot Hole Inspector",                 "Position Currently Vacant"],
  ["Trap Quality Assurance",              "Clearly Not Rigorous Enough"],
  ["Dramatic Lighting",                   "A Single Torch, Dying"],
  ["Script Supervision",                  "Unmonitored Since Act One"],
  ["Villain Motivation Consultant",       "Working on It"],
  ["Dramatic Music",                      "The GM's Spotify, Eventually"],
  ["Interior Design",                     "Dungeon Aesthetic Quarterly"],
  ["Door Safety Inspector",              "Retired After the Third Mimic"],
  ["Encounter Balancing",                 "In Retrospect, No"],
  ["Prophecy Drafting",                   "Intentionally Vague LLC"],
  ["Wardrobe",                            "What Everyone Could Afford"],
  ["Puzzle Design",                       "A Cry for Help"],
  ["Tavern Authenticity Consultant",      "Smells About Right"],
  ["Background NPC Coordinator",         "The Guy in the Corner"],
  ["Horse Continuity",                    "We Don't Talk About the Horse"],
  ["Villain Exit Choreography",           "They Got Away Again"],
  ["Dramatic Pause Timing",              "Off by Three Seconds"],
  ["Secret Door Placement",              "Somewhere They'll Never Look"],
  ["Crowd Simulation",                    "Six People and an Echo"],
  ["Loot Table Curator",                  "Optimistically"],
  ["Morale Officer",                      "The Dog, Technically"],
  ["Foreshadowing",                       "Several Hints Ignored"],
  ["Ominous Prophecy Delivery",          "Read Aloud Too Quickly"],
  ["Environmental Hazard Consultant",     "The Pit Was There for a Reason"],
  ["Inn Ambiance",                        "Suspicious, But Warm"],
  ["Session Pacing",                      "We Tried"],
  ["Final Boss Hype Coordinator",        "Building to Something"],
  ["Cliffhanger Management",             "Sorry"],
  ["Skeleton Procurement",               "An Ancient Burial Ground"],
  ["Arcane Special Effects",             "The Wizard, Who Did Not Ask"],
  ["Character Arc Consultant",           "Growth Was Attempted"],
  ["Miscellaneous Betrayals",            "You Know Who You Are"],
  ["Scheduling Coordinator",             "A Shared Calendar in Crisis"],
  ["Last-Minute Recap Services",         "The One Player Who Was Paying Attention"],
  ["Secret Villain Monologue Editor",    "Trimmed for Time, Sadly"],
  ["Potion Labeling Department",         "Optimism and Vibes"],
  ["Bridge Structural Integrity",        "Not Independently Verified"],
  ["Accent Continuity",                  "Ambitious, but Fluid"],
  ["Disguise Quality Control",           "A Hat and Confidence"],
  ["Torchlight Philosophy",              "Dim, but Committed"],
  ["Rumor Distribution",                 "The Tavern Staff Union"],
  ["Map Legend Translation",             "Interpretive at Best"],
  ["Difficult Choice Facilitation",      "Panic Under Pressure Ltd."],
  ["Emergency Resurrection Liaison",     "On Retainer, Regretfully"],
  ["Dungeon Moisture Management",        "Persistent Dripping"],
  ["Moral Support",                      "One Extremely Brave Snack"],
  ["Travel Montage Coordination",        "Three Roads and a Fade-Out"],
  ["Unpaid Emotional Labor",             "The Party Face"],
  ["Cursed Object Placement",            "Within Easy Reach"],
  ["Battlefield Debris",                 "Generously Distributed"],
  ["Ancient Evil Containment",           "Holding for Now"],
  ["Administrative Oversight",           "A Seal Nobody Read"],
];

// Executive Producers — pick a few random ones
const EXEC_PRODUCERS = [
  "Whoever Brought Snacks",
  "The Player Who Read the Rulebook",
  "An Optimistic Game Master",
  "Three Separate Arguments About Grapple Rules",
  "One (1) Successful Diplomacy Check",
  "The Person Who Remembered to Level Up",
  "Several Whispered Conversations the GM Definitely Heard",
  "That One Homebrew Rule Everyone Forgot About",
  "The Character Sheet Made in the Car on the Way Over",
  "A Shared Delusion That This Would Go Smoothly",
  "The Power of Friendship (and High Initiative)",
  "Whoever Agreed to Track Initiative",
  "Unearned Confidence and Favourable Dice",
  "A GM Who Loves You All and Is Very Tired",
  "Nobody's Second Character Option, Somehow",
  "A Dice Bag of Dubious Intent",
  "One Overprepared Notes Document",
  "Whoever Remembered the Session Summary",
  "The Last Health Potion Nobody Wanted to Use",
  "A Tablewide Agreement to Blame the Dice",
  "Two Emergency Bathroom Breaks and a Cliffhanger",
  "The Person Who Quietly Fixed the Math",
  "Someone Saying 'This Will Be Fine' Right Before It Wasn't",
];

// Filmed on location entries
const FILMED_ON_LOCATION = [
  "Someone's Kitchen Table",
  "The Definitive Edition of the Battlemaps",
  "A Very Detailed Mental Image",
  "Roll20, More or Less",
  "A Kitchen Table That Has Seen Things",
  "The Imagination of Someone Who Read One History Book",
  "Three Sticky Notes and a Whiteboard",
  "A Map That Was Definitely to Scale",
  "Somewhere Dark and Slightly Damp",
  "A Location That Looked Better in the GM's Head",
  "A Folder Full of Maps Named Final-Final-UseThisOne",
  "The Exact Center of the Encounter Template",
  "One Tavern Reused Four Different Ways",
  "An Alleyway Full of Suspiciously Repositioned Crates",
  "The Part of the Dungeon Behind the GM Screen",
  "A Wilderness Hex Nobody Expected to Matter",
  "A Perfectly Ordinary Basement That Was Not Ordinary",
  "The Stretch of Road Where Bad Decisions Flourish",
];

const SPECIAL_THANKS = [
  "The dice (for occasionally cooperating)",
  "Natural 1s — for keeping things interesting",
  "Natural 20s — for appearing at the least dramatically satisfying moments",
  "The rules — for being occasionally remembered",
  "Snacks — for being there when nothing else was working",
  "Everyone who said 'I have a plan' and did not have a plan",
  "That one NPC everyone got oddly attached to",
  "Whoever kept forgetting their character sheet",
  "The villain, for waiting patiently while we argued about the door",
  "Every trap that was spotted on the second character's turn",
  "Session zero — remembered fondly, honored rarely",
  "The fifteen minutes spent naming the horse",
  "Off-topic conversations that somehow became canon",
  "Everyone who rolled Stealth with disadvantage and somehow passed",
  "The cleric, for healing people slightly too late",
  "The wizard, for using their biggest spell in the first encounter",
  "Whoever drew the map — it was very evocative",
  "The one NPC whose name the GM had to quietly look up every session",
  "The decision to split the party, which worked out fine, technically",
  "Everyone who remembered to use their reaction",
  "The improvised solution nobody expected to work",
  "The enemy that rolled minimum damage every single time",
  "All the plot threads that will definitely come up later",
  "The dead characters who made this possible",
  "The halfling who stood in the way of literally everything",
  "Everyone who took Perception as a dump stat and lived to regret it",
  "The table, for enduring everything that was placed upon it",
  "Tea, coffee, and whatever that third thing was",
  "The critical hit that changed everything",
  "The critical failure that changed everything else",
  "Every spell slot spent on the wrong problem",
  "The boss mechanic everyone understood one round too late",
  "The tactical map ping that explained absolutely nothing",
  "Whoever said 'don't worry, I can tank this'",
  "The enemy whose save bonus turned out to be deeply offensive",
  "The shopping trip that somehow took longer than the dungeon",
  "All the notes labeled IMPORTANT and never revisited",
  "The one door that really did need checking",
  "Everyone who prepared a speech instead of an escape route",
  "The rule clarification that arrived four sessions later",
  "The backup character waiting patiently in the wings",
  "Every villain voice that drifted into pirate unexpectedly",
];

const DISCLAIMERS = [
  "No adventurers were permanently harmed in the making of this campaign.\n(Several were inconvenienced. Many rolled poorly.)",
  "All monsters appearing in this campaign are fictional.\nAny resemblance to actual monsters, living or undead, is purely coincidental.",
  "The events depicted are entirely fictional and occurred entirely within the imagination.\nThe dice results, however, were very real and very devastating.",
  "This campaign was filmed on location in a world that doesn't exist.\nAll decisions made by player characters were their own.",
  "The GM reserves the right to have definitely planned all of that.\nAny evidence to the contrary is circumstantial.",
  "No familiars were harmed during this production.\nSeveral were forgotten. That is a different matter.",
  "Any similarity to actual historical events is either coincidental\nor the result of someone having read half a Wikipedia article.",
  "The management is not responsible for emotional attachment to NPCs\nwho were introduced as comic relief and then killed off.",
  "All traps were tested by professionals.\nThe professionals were not consulted about the results.",
  "No narrative foreshadowing was wasted in the making of this campaign.\nIt was, however, frequently ignored.",
  "All strategic plans were performed by trained adventurers.\nPlease do not attempt them at your own table without supervision.",
  "No kings, liches, or tavern owners endorsed the actions depicted herein.\nTheir legal positions remain ongoing.",
  "All maps were shown by a professional game master on a closed course.\nVisibility conditions may not reflect actual torchlight.",
  "Viewer discretion is advised for strong language, reckless heroism,\nand scenes of sustained tactical overconfidence.",
  "No promises made by suspicious NPCs should be considered binding.\nOffer void where prophecy applies.",
];

const STINGERS = [
  "The horse is still out there. Waiting.",
  "No one ever did go back for the loot in room 7.",
  "The blacksmith whose cart you overturned remembers.",
  "That guard you bribed is still thinking about it.",
  "The villain's apprentice took very detailed notes.",
  "The inn you burned down had a five-star rating.",
  "The rope was not, in fact, long enough.",
  "The NPC you ignored was the king.",
  "Someone, somewhere, is still holding that door open.",
  "The prophecy has been reinterpreted. Again.",
  "The familiar found its way home eventually.",
  "The mimic is still in there. Nobody checked.",
  "The treasure was behind the first door the whole time.",
  "Bob the guard filed a formal complaint.",
  "The mysterious stranger at the bar was exactly who you thought.",
  "The dice remember. The dice always remember.",
  "That random villager wrote a memoir. It sold well.",
  "The cursed item was never officially identified.",
  "The exit was to the left. It was always to the left.",
  "The shopkeeper is still waiting for payment.",
  "The wizard wrote a 14-page rebuttal to the ruling and lost it.",
  "The goblin you spared now runs a thriving roadside business.",
  "Someone eventually opened the letter marked 'Do Not Open Yet.'",
  "The backup plan became the main plan and then also failed.",
  "The horse remembers who suggested crossing the bridge.",
  "One of those statues was absolutely watching you leave.",
  "The dungeon boss updated their security procedures.",
  "The bard's song about this was legally actionable.",
  "The local inn now has a surcharge named after the party.",
  "Somewhere, an unopened chest is still being smug about it.",
];

const OPENING_TAGLINES = [
  "A Campaign in Several Parts,\nMost of Which Were Not Originally Planned",
  "An Adventure in Multiple Acts,\nOnly Some of Which Survived First Contact with the Players",
  "A Story of Heroism, Questionable Decisions,\nand Administrative Oversight",
  "A Tabletop Epic in Uneven Chapters,\nHeld Together by Vibes and Initiative Rolls",
  "A Grand Tale of Courage, Chaos,\nand Notes the GM Can No Longer Fully Interpret",
  "A Production in Many Scenes,\nSeveral of Which Escaped Containment",
  "A Narrative Experience in Repeated Course Correction",
  "A Campaign of Bold Choices,\nMost of Them Made Under Time Pressure",
];

const SF2E_CREDITS = {
  openingTaglines: [
    "A Mission in Several Phases,\nMost of Which Were Not in the Flight Plan",
    "An Expedition Beyond the Known Map,\nWith Unscheduled Repairs Along the Way",
    "A Story of Courage, Chaos,\nand Questionable Life-Support Decisions",
    "A Tactical Operation in Uneven Orbits,\nHeld Together by Duct Tape and Initiative",
    "A Voyage of Discovery,\nAccidental Trespassing, and Administrative Oversight",
    "A Campaign of Bold Maneuvers,\nMost of Them Made Under Fire",
  ],
  sillyRoles: [
    "Chief Dice Fumbler",
    "Senior Starship Systems Blamer",
    "Director of Suspicious Dice Rolling",
    "Head of Unnecessary Rules Research",
    "Executive Airlock Procedure Forgetter",
    "Natural 1 Enthusiast",
    "Chief Tactical Scanner Misreader",
    "Director of Standing in the Explosions",
    "Lead Unauthorized Boarding Specialist",
    "Senior 'I Have a Plan' Officer (Plan Pending)",
    "Chief Cover Allocation Mismanager",
    "Head of Asking the Alien the Wrong Question",
    "Executive Producer of Needless System Checks",
    "Director of Dramatic Helmet Removal",
    "Chief 'Can I Hack That?' Inquirer",
    "Senior Emergency Rerouting Coordinator",
    "Lead Suspicious Cargo Appraiser",
    "Director of Befriending the Hostile Lifeform",
    "Head of Forgetting Which Planet We Are On",
    "Chief Character Backstory Transmission Officer",
    "Senior 'What Does the Scanner Say?' Asker",
    "Director of Ignoring the Obvious Escape Pod",
    "Executive 'This Is Probably Safe' Analyst",
    "Head of Misplacing the Mission Brief",
    "Lead Cooldown of Tablewide Side-Eyes",
  ],
  executiveProducers: [
    "Whoever Brought Snacks Into the Cockpit",
    "The Player Who Read the Equipment Rules",
    "An Optimistic Mission Commander",
    "Three Separate Arguments About Cover",
    "One (1) Successful Diplomacy Check",
    "The Person Who Remembered to Track Ammunition",
    "Several Whispered Conversations the GM Definitely Heard",
    "A Shared Delusion That This Would Be a Routine Mission",
    "The Power of Friendship (and Emergency Thrusters)",
    "Whoever Agreed to Track Initiative",
    "Unearned Confidence and Favourable Dice",
    "A GM Who Loves You All and Is Very Tired",
  ],
  epitaphs: [
    "Gone, but not forgotten",
    "Technically still on the crew manifest",
    "Lost as they lived — at an inopportune moment",
    "Their dice have been placed in quarantine",
    "Beloved by all, warned by none",
    "Their rescue beacon is still transmitting",
    "Fell so that others could make the same mistake",
    "Last seen making a very confident decision",
    "They asked if it was hostile. It was.",
    "Taken before their time, but not before initiative",
    "They died doing what they loved: overcommitting",
    "The void was not prepared for this amount of backstory",
    "Their legend survives in increasingly inaccurate mission reports",
    "They left us as they found us: under severe pressure",
  ],
  crewPool: [
    ["Flight Planning", "Revised After Launch"],
    ["Head of Xenobiology", "Do Not Pet the Specimen"],
    ["Director of Shipboard Ambiance", "One Flickering Console"],
    ["Chief Archive Officer", "Search Results Inconclusive"],
    ["Sound Design", "The Collective Alarm Response"],
    ["Catering", "Nutrient Paste, Somehow Spicy"],
    ["Legal Counsel", "Arguing With the Mission Parameters"],
    ["Insurance", "Void Where Prohibited"],
    ["Atmospheric Effects", "The Ventilation Is Singing"],
    ["Animal Containment", "The Familiar Is Not on the Manifest"],
    ["Continuity", "Nobody Logged the Jump"],
    ["Stunt Coordination", "The Pilot, Unasked"],
    ["Medical Advisor", "The Medkit, Eventually"],
    ["Explosives Consultant", "The Engineer, Probably"],
    ["Negotiation Coach", "Out of Communications Range"],
    ["Exit Strategy", "Still Being Workshopped"],
    ["Map Accuracy", "Not Guaranteed Beyond This Sector"],
    ["Cargo Manifest", "Optimistically Incomplete"],
    ["Security Audit", "Several Doors Were Unlocked"],
    ["Dramatic Lighting", "A Single Emergency Strip"],
    ["Mission Briefing Editor", "Trimmed for Oxygen"],
    ["Villain Motivation Consultant", "Working on It"],
    ["Dramatic Music", "The GM's Spotify, Eventually"],
    ["Hull Integrity", "Not Independently Verified"],
    ["Robot Etiquette", "A Learning Experience"],
    ["Navigation", "Somewhere in This Galaxy"],
    ["Stasis Pod Inspector", "Please Do Not Open"],
    ["Final Encounter Hype Coordinator", "Building to Something"],
    ["Cliffhanger Management", "Transmission Interrupted"],
    ["Quantum Prop Continuity", "Observed Differently by Everyone"],
  ],
  filmedOnLocation: [
    "The Command Deck",
    "A Remote Outpost With Suspiciously Few Exits",
    "Three Sticky Notes and a Holographic Display",
    "A Map That Was Definitely to Scale",
    "Somewhere Dark and Slightly Airless",
    "A Sector That Looked Safer in the Briefing",
    "A Cargo Bay Full of Crates Nobody Scanned",
    "The Exact Center of the Asteroid Belt",
    "One Reused Spaceport With Four Different Names",
    "An Uncharted Moon and Its Extremely Charted Problems",
    "The Part of the Ship Behind the GM Screen",
    "A Derelict Station Nobody Expected to Explore",
    "The Stretch of Vacuum Where Bad Decisions Flourish",
  ],
  specialThanks: [
    "The dice (for occasionally cooperating)",
    "Natural 1s — for keeping the mission interesting",
    "Natural 20s — for arriving at the least convenient moments",
    "The rules — for being occasionally remembered",
    "Snacks — for surviving the watch rotation",
    "Everyone who said 'I have a plan' and did not have a plan",
    "That one alien everyone got oddly attached to",
    "Whoever kept forgetting their character sheet",
    "The station administrator who waited patiently while we argued about docking",
    "Every hazard that was spotted on the second character's turn",
    "The medic, for healing people slightly too late",
    "The operative, for using their best trick in the first encounter",
    "Whoever drew the map — it was very evocative",
    "The crew member whose designation the GM had to quietly look up every session",
    "The decision to split the party, which worked out fine, technically",
    "Everyone who remembered to use their reaction",
    "The improvised solution nobody expected to work",
    "The enemy that rolled minimum damage every single time",
    "All the mission threads that will definitely come up later",
    "The backup character waiting patiently in the cryopod",
    "Every villain voice that drifted into pirate unexpectedly",
  ],
  disclaimers: [
    "No explorers were permanently harmed in the making of this campaign.\n(Several were inconvenienced. Many rolled poorly.)",
    "All alien lifeforms appearing in this campaign are fictional.\nAny resemblance to actual alien life is purely coincidental.",
    "The events depicted are entirely fictional and occurred entirely within the imagination.\nThe dice results, however, were very real and very devastating.",
    "This campaign was recorded on location in a sector that doesn't exist.\nAll decisions made by the crew were their own.",
    "The mission commander reserves the right to have definitely planned all of that.\nAny evidence to the contrary is circumstantial.",
    "No service robots were harmed during this production.\nSeveral were ignored. That is a different matter.",
    "All airlocks were tested by professionals.\nThe professionals were not consulted about the results.",
    "No navigation data was wasted in the making of this campaign.\nIt was, however, frequently ignored.",
    "All strategic plans were performed by trained spacers.\nPlease do not attempt them without supervision.",
    "No admirals, androids, or station owners endorsed the actions depicted herein.\nTheir legal positions remain ongoing.",
  ],
  stingers: [
    "The escape pod is still out there. Waiting.",
    "No one ever did go back for the cargo in bay 7.",
    "The station quartermaster remembers who overturned the cart.",
    "That customs officer is still thinking about it.",
    "The hostile AI's apprentice took very detailed notes.",
    "The outpost had a five-star rating before the party arrived.",
    "The tether was not, in fact, long enough.",
    "The alien you ignored was the ambassador.",
    "Someone, somewhere, is still holding the pressure door open.",
    "The mission report has been reclassified. Again.",
    "The familiar found its way back to the ship eventually.",
    "The derelict station is still transmitting. Nobody checked why.",
    "The supply cache was behind the first panel the whole time.",
    "The quartermaster filed a formal complaint.",
    "The mysterious traveler at the spaceport was exactly who you thought.",
    "The dice remember. The dice always remember.",
    "That random colonist wrote a memoir. It sold well.",
    "The unidentified device was never officially identified.",
    "The exit was to the left. It was always to the left.",
    "The merchant is still waiting for payment.",
    "The engineer wrote a 14-page rebuttal to the ruling and lost it.",
    "The creature you spared now runs a thriving roadside refueling station.",
    "Someone eventually opened the crate marked 'Do Not Open Yet.'",
    "The backup plan became the main plan and then also failed.",
    "One of those statues was absolutely watching you leave.",
    "The station boss updated their security procedures.",
    "The crew's song about this was legally actionable.",
    "Somewhere, an unopened escape pod is still being smug about it.",
  ],
};

// ── Helpers ────────────────────────────────────────────────────────────────

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function sp(n = 1) {
  return `<span class="ec-spacer" style="display:block;height:${n}em"></span>`;
}

function divider() {
  return `${sp(0.8)}<hr class="ec-divider">${sp(0.8)}`;
}

function sectionHeader(text) {
  return `<div class="ec-section-header">${text}</div>${sp(0.6)}`;
}

function creditRow(left, right) {
  return `
    <div class="ec-credit-row">
      <span class="ec-credit-left">${left}</span>
      <span class="ec-credit-dots"></span>
      <span class="ec-credit-right">${right}</span>
    </div>`;
}

// ── Music ──────────────────────────────────────────────────────────────────
// Foundry's playlist system is server-authoritative and syncs to all clients
// automatically — including late-joiners. So the GM just needs to
// play/stop; everyone hears it with no extra socket work needed.

/**
 * Snapshot every currently-playing sound across all playlists, pause them,
 * then start the credits track.
 */
function startMusic() {
  if (!game.user.isGM) return;

  // ── 1. Snapshot and pause everything currently playing ──────────────────
  pausedSnapshot = [];
  for (const playlist of game.playlists) {
    for (const sound of playlist.sounds) {
      if (sound.playing) {
        pausedSnapshot.push({ playlistId: playlist.id, soundId: sound.id });
        playlist.stopSound(sound);
      }
    }
  }
  if (pausedSnapshot.length) {
    console.log(`[End Credits] Paused ${pausedSnapshot.length} track(s) for credits.`);
  }

  // ── 2. Start the credits track ───────────────────────────────────────────
  const playlistId = game.settings.get(MODULE_ID, "endCreditsPlaylistId");
  const soundId    = game.settings.get(MODULE_ID, "endCreditsSoundId");
  if (!playlistId || !soundId) return;

  const playlist = game.playlists.get(playlistId);
  if (!playlist) { console.warn("[End Credits] Playlist not found:", playlistId); return; }

  const sound = playlist.sounds.get(soundId);
  if (!sound)  { console.warn("[End Credits] Track not found:", soundId); return; }

  playlist.playSound(sound);
}

/**
 * Stop the credits track, then resume whatever was playing before.
 */
function stopMusic() {
  if (!game.user.isGM) return;

  // ── 1. Stop the credits track ────────────────────────────────────────────
  const playlistId = game.settings.get(MODULE_ID, "endCreditsPlaylistId");
  const soundId    = game.settings.get(MODULE_ID, "endCreditsSoundId");
  if (playlistId && soundId) {
    const playlist = game.playlists.get(playlistId);
    const sound    = playlist?.sounds.get(soundId);
    if (sound?.playing) playlist.stopSound(sound);
  }

  // ── 2. Restore previously-playing sounds ─────────────────────────────────
  for (const { playlistId: pid, soundId: sid } of pausedSnapshot) {
    const playlist = game.playlists.get(pid);
    const sound    = playlist?.sounds.get(sid);
    if (sound && !sound.playing) {
      playlist.playSound(sound);
    }
  }
  if (pausedSnapshot.length) {
    console.log(`[End Credits] Restored ${pausedSnapshot.length} track(s).`);
  }
  pausedSnapshot = [];
}

// ── Image Config FormApplication ───────────────────────────────────────────

class EcImageConfig extends FormApplication {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id:            "ec-image-config",
      title:         "End Credits — Background Image",
      template:      "modules/pf2-david-music-control/templates/end-credits-image-config.hbs",
      width:         500,
      height:        "auto",
      closeOnSubmit: true,
    });
  }

  getData() {
    return {
      backgroundImage: game.settings.get(MODULE_ID, "endCreditsBackgroundImage"),
      bgOpacity: Math.round((game.settings.get(MODULE_ID, "endCreditsBgOpacity") ?? 1.0) * 100),
    };
  }

  activateListeners(html) {
    super.activateListeners(html);

    html.find("#ec-bg-browse").on("click", () => {
      new FilePicker({
        type:     "imagevideo",
        current:  html.find('[name="backgroundImage"]').val(),
        callback: path => html.find('[name="backgroundImage"]').val(path),
      }).browse();
    });

    html.find("#ec-bg-clear").on("click", () => {
      html.find('[name="backgroundImage"]').val("");
    });
  }

  async _updateObject(_event, formData) {
    await game.settings.set(MODULE_ID, "endCreditsBackgroundImage", formData.backgroundImage ?? "");
    await game.settings.set(MODULE_ID, "endCreditsBgOpacity", (parseFloat(formData.bgOpacity) || 100) / 100);
    ui.notifications.info("End Credits: background image saved.");
  }
}

// ── Music Config FormApplication ───────────────────────────────────────────

class EcMusicConfig extends FormApplication {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id:            "ec-music-config",
      title:         "End Credits — Music Settings",
      template:      "modules/pf2-david-music-control/templates/end-credits-music-config.hbs",
      width:         480,
      height:        "auto",
      closeOnSubmit: true,
    });
  }

  getData() {
    const savedPlaylistId = game.settings.get(MODULE_ID, "endCreditsPlaylistId");
    const savedSoundId    = game.settings.get(MODULE_ID, "endCreditsSoundId");

    const playlists = game.playlists.map(p => ({
      id:       p.id,
      name:     p.name,
      selected: p.id === savedPlaylistId,
    }));

    const selectedPlaylist = game.playlists.get(savedPlaylistId);
    const sounds = selectedPlaylist
      ? selectedPlaylist.sounds.map(s => ({
          id:       s.id,
          name:     s.name,
          selected: s.id === savedSoundId,
        }))
      : [];

    return { playlists, sounds, savedPlaylistId, savedSoundId };
  }

  activateListeners(html) {
    super.activateListeners(html);

    // When playlist changes, reload the track list dynamically
    html.find("#ec-playlist-select").on("change", async ev => {
      const playlistId = ev.target.value;
      const playlist   = game.playlists.get(playlistId);
      const trackSel   = html.find("#ec-sound-select");
      trackSel.empty();

      if (!playlist || playlist.sounds.size === 0) {
        trackSel.append(`<option value="">— No tracks —</option>`);
        return;
      }

      trackSel.append(`<option value="">— Pick a track —</option>`);
      for (const sound of playlist.sounds) {
        trackSel.append(`<option value="${sound.id}">${sound.name}</option>`);
      }
    });
  }

  async _updateObject(_event, formData) {
    await game.settings.set(MODULE_ID, "endCreditsPlaylistId", formData.playlistId ?? "");
    await game.settings.set(MODULE_ID, "endCreditsSoundId",    formData.soundId    ?? "");
    ui.notifications.info("End Credits: music settings saved.");
  }
}

// ── Credits HTML builder ───────────────────────────────────────────────────

/**
 * Returns the non-GM user who owns this actor, if any.
 * Prefers someone currently active; falls back to any owner.
 */
function getPlayerForActor(actor) {
  const OWNER_LEVEL = 3;
  const ownership   = actor.ownership ?? {};
  const ownerIds    = Object.entries(ownership)
    .filter(([id, level]) => level >= OWNER_LEVEL && id !== "default")
    .map(([id]) => id);
  if (!ownerIds.length) return null;
  const nonGmUsers = game.users.filter(u => !u.isGM);
  return (
    nonGmUsers.find(u => ownerIds.includes(u.id) && u.active) ??
    nonGmUsers.find(u => ownerIds.includes(u.id)) ??
    null
  );
}

function buildCreditsHTML() {
  const gm        = game.users.find(u => u.isGM);
  const worldName = game.world.title || "This Campaign";
  const system    = game.system.title || "Unknown System";
  const creditSet = game.system?.id === "sf2e"
    ? SF2E_CREDITS
    : {
        openingTaglines: OPENING_TAGLINES,
        sillyRoles: SILLY_ROLES,
        executiveProducers: EXEC_PRODUCERS,
        epitaphs: null,
        crewPool: CREW_POOL,
        filmedOnLocation: FILMED_ON_LOCATION,
        specialThanks: SPECIAL_THANKS,
        disclaimers: DISCLAIMERS,
        stingers: STINGERS,
      };

  // Build cast from party members; fall back to non-GM users if no party
  const partyActor   = game.actors.party ?? game.actors.find(a => a.type === "party");
  const partyMembers = partyActor?.members?.contents ?? partyActor?.members
    ?? game.actors.filter(a => a.type === "character" && a.hasPlayerOwner);
  const castEntries  = partyMembers.map(m => ({ character: m, player: getPlayerForActor(m) }));
  const fallbackPlayers = game.users.filter(u => !u.isGM && u.name);

  let html = "";

  // ── Opening title ─────────────────────────────────────────────────────────
  html += sp(5);
  html += `<div class="ec-tagline">A ${system} Production</div>`;
  html += sp(1.5);
  html += `<div class="ec-world-title">${worldName}</div>`;
  html += sp(0.5);
  html += `<div class="ec-tagline">${pick(creditSet.openingTaglines)}</div>`;
  html += sp(2);

  if (gm) {
    html += `<div class="ec-role-connector">Written, Directed, and Desperately Improvised by</div>`;
    html += sp(0.4);
    html += `<div class="ec-player-name">${gm.name}</div>`;
    html += sp(0.5);
    html += `<div class="ec-role-connector">Executive Producer</div>`;
    html += sp(0.2);
    html += `<div class="ec-role">${gm.name}</div>`;
  }

  // ── Executive Producers ───────────────────────────────────────────────────
  html += divider();
  html += sectionHeader("Executive Producers");
  html += sp(0.5);
  for (const ep of shuffle(creditSet.executiveProducers).slice(0, 2)) {
    html += `<div class="ec-role">${ep}</div>`;
    html += sp(0.3);
  }

  // ── Cast ──────────────────────────────────────────────────────────────────
  html += divider();
  html += sectionHeader("Cast of Adventurers");

  const rolePool = shuffle(creditSet.sillyRoles);
  let roleIndex  = 0;

  if (castEntries.length > 0) {
    for (const { character, player } of shuffle(castEntries)) {
      const rolesForPlayer = 2;
      html += sp(1);
      html += `<div class="ec-player-name">${character.name}</div>`;
      if (player) {
        html += sp(0.15);
        html += `<div class="ec-role-connector">played by ${player.name}</div>`;
      }
      html += sp(0.25);
      html += `<div class="ec-role-connector">as</div>`;
      html += sp(0.2);
      for (let i = 0; i < rolesForPlayer; i++) {
        html += `<div class="ec-role">${rolePool[roleIndex++ % rolePool.length]}</div>`;
      }
    }
  } else if (fallbackPlayers.length > 0) {
    for (const player of shuffle(fallbackPlayers)) {
      const rolesForPlayer = 2;
      html += sp(1);
      html += `<div class="ec-player-name">${player.name}</div>`;
      html += sp(0.25);
      html += `<div class="ec-role-connector">as</div>`;
      html += sp(0.2);
      for (let i = 0; i < rolesForPlayer; i++) {
        html += `<div class="ec-role">${rolePool[roleIndex++ % rolePool.length]}</div>`;
      }
    }
  } else {
    html += sp(1);
    html += `<div class="ec-role-connector">(No adventurers found to credit.\nThis speaks volumes.)</div>`;
  }

  // ── In Memoriam ───────────────────────────────────────────────────────────
  const epitaphs = creditSet.epitaphs ?? [
    "Gone, but not forgotten",
    "Technically still on the character sheet",
    "Died as they lived — at an inopportune moment",
    "We said we'd make a memorial. We didn't.",
    "Their dice have been retired with honour",
    "Beloved by all, warned by none",
    "The cleric rolled a 2 on the death save. We don't talk about it.",
    "May their resurrection be swift and affordable",
    "Fell so that others could make the same mistake",
    "Remembered every session, learned from never",
    "Briefly alive, permanently iconic",
    "Last seen making a very confident decision",
    "They asked if it looked trapped. It did.",
    "Their sacrifice will be honored, summarized, and probably misremembered",
    "Taken before their time, but not before initiative",
    "They died doing what they loved: overcommitting",
    "The afterlife was not prepared for this amount of backstory",
    "Their legend lives on in increasingly inaccurate retellings",
    "Gone to that great holding cell in the sky",
    "They left us as they found us: under severe pressure",
  ];

  const isDead  = a => a.system?.attributes?.hp?.value === 0 || a.system?.attributes?.dying?.value > 0;
  const memoriamFolderName = game.settings.get(MODULE_ID, "endCreditsMemoriamFolder")?.trim();
  const memoriamFolder = findActorFolderByPath(memoriamFolderName);
  const deadParty = partyMembers.filter(isDead);
  const deadFolderActors = memoriamFolder ? getActorsInFolderTree(memoriamFolder) : [];
  const deadActors = memoriamFolderName
    ? deadFolderActors
    : deadParty.length > 0
      ? deadParty
      : (game.actors?.filter(a => a.type === "character" && isDead(a)) ?? []);

  if (deadActors.length > 0) {
    html += divider();
    html += sectionHeader("In Memoriam");
    html += sp(0.5);
    html += `<div class="ec-fine-print" style="font-style:italic;margin-bottom:0.6em;">They fought bravely. They rolled poorly. They will be missed.</div>`;
    for (const actor of deadActors) {
      const player = getPlayerForActor(actor);
      html += sp(0.5);
      html += `<div class="ec-player-name" style="font-size:1.1em;">${actor.name}</div>`;
      if (player) {
        html += `<div class="ec-role-connector" style="font-size:0.8em;">played by ${player.name}</div>`;
      }
      html += `<div class="ec-role-connector" style="font-size:0.8em;margin-top:0.1em;">${pick(epitaphs)}</div>`;
    }
  }

  // ── Production crew ───────────────────────────────────────────────────────
  html += divider();
  html += sectionHeader("Production");
  html += sp(0.5);
  // Pick a random 14–18 entries from the full crew pool each time
  const crewCount = 6 + Math.floor(Math.random() * 3);
  for (const [role, name] of shuffle(creditSet.crewPool).slice(0, crewCount)) {
    html += creditRow(role, name);
    html += sp(0.15);
  }

  // ── Filmed on location ────────────────────────────────────────────────────
  html += divider();
  html += sectionHeader("Filmed on Location");
  html += sp(0.4);
  html += `<div class="ec-role">${pick(creditSet.filmedOnLocation)}</div>`;
  html += sp(0.3);
  html += `<div class="ec-fine-print">No locations were harmed in the making of this production.\nSeveral were looted.</div>`;

  // ── Special thanks ────────────────────────────────────────────────────────
  html += divider();
  html += sectionHeader("Special Thanks");
  html += sp(0.5);
  // Pick 10–14 at random so it's different each time
  const thanksCount = 4 + Math.floor(Math.random() * 2);
  for (const line of shuffle(creditSet.specialThanks).slice(0, thanksCount)) {
    html += `<div class="ec-fine-print">${line}</div>`;
    html += sp(0.4);
  }

  // ── Disclaimers ───────────────────────────────────────────────────────────
  html += divider();
  // Pick 2–3 disclaimers
  const disclaimerCount = 1 + Math.floor(Math.random() * 2);
  for (const d of shuffle(creditSet.disclaimers).slice(0, disclaimerCount)) {
    html += `<div class="ec-fine-print">${d}</div>`;
    html += sp(1);
  }

  // ── Sign-off ──────────────────────────────────────────────────────────────
  html += divider();
  html += sp(1);
  html += `<div class="ec-tagline">${worldName}</div>`;
  html += sp(0.4);
  html += `<div class="ec-fine-print">is a ${system} production.<br>
    All rights reserved.<br>
    Any rights not reserved were lost when somebody rolled a 1 on Arcana.</div>`;

  // ── Post-credits stinger ──────────────────────────────────────────────────
  html += sp(6);
  html += divider();
  html += sp(1);
  html += `<div class="ec-fine-print" style="font-style:italic;color:rgba(200,185,140,0.7);">${pick(creditSet.stingers)}</div>`;
  html += sp(10);

  return html;
}

// ── Background builder ────────────────────────────────────────────────────

const VIDEO_EXTS = new Set(["mp4", "webm", "ogg", "mov"]);

function buildBackgroundHTML() {
  const src = game.settings.get(MODULE_ID, "endCreditsBackgroundImage")?.trim();
  if (!src) return "";   // no image selected — transparent overlay as before

  const ext = src.split(".").pop().toLowerCase();
  if (VIDEO_EXTS.has(ext)) {
    // Video files animate natively; muted required for autoplay in browsers
    const opacity = game.settings.get(MODULE_ID, "endCreditsBgOpacity") ?? 1.0;
    return `<video id="ec-bg" src="${src}" autoplay loop muted playsinline style="opacity:${opacity}"></video>`;
  }
  // Images (including GIFs, which animate automatically)
  const opacity = game.settings.get(MODULE_ID, "endCreditsBgOpacity") ?? 1.0;
  return `<img id="ec-bg" src="${src}" alt="" style="opacity:${opacity}" />`;
}

// ── Overlay lifecycle ──────────────────────────────────────────────────────

function startCredits(
  creditsHtml = currentCreditsHtml || getStoredCreditsHtml() || buildCreditsHTML(),
  startedAt = currentCreditsStartedAt || getStoredCreditsStartedAt() || Date.now(),
) {
  if (creditsActive) return;
  setCreditsActive(true);
  currentCreditsHtml = creditsHtml;
  currentCreditsStartedAt = startedAt;

  // Leave the Foundry sidebar uncovered so players can still use chat,
  // compendiums, etc. while the credits roll. Read the sidebar width at
  // start time so we respect collapsed/resized states.
  const sidebar       = document.querySelector("#sidebar");
  const sidebarWidth  = sidebar ? sidebar.offsetWidth + 4 : 0;

  const overlay = document.createElement("div");
  overlay.id = "ec-overlay";
  overlay.style.right = `${sidebarWidth}px`;
  overlay.innerHTML = `
    ${buildBackgroundHTML()}
    <div id="ec-bg-dim"></div>
    <div id="ec-fade-top"></div>
    <div id="ec-inner">${creditsHtml}</div>
    <div id="ec-fade-bottom"></div>
    ${game.user.isGM ? `<button id="ec-stop-btn" title="Stop Credits">
      <i class="fas fa-stop-circle"></i> Stop Credits
    </button>` : ""}
  `;

  document.body.appendChild(overlay);
  document.getElementById("ec-stop-btn")?.addEventListener("click", () => apiToggle());

  const inner = document.getElementById("ec-inner");
  const topOffset = window.innerHeight + 40;
  const pixelsPerMs = SCROLL_SPEED / 16.6666666667;

  function getScrollPosition(el) {
    const elapsed = Math.max(0, Date.now() - startedAt);
    const travel = elapsed * pixelsPerMs;
    const cycleDistance = topOffset + el.offsetHeight + 40;
    return topOffset - (travel % cycleDistance);
  }

  posY = getScrollPosition(inner);
  inner.style.transform = `translateX(-50%) translateY(${posY}px)`;

  function tick() {
    if (!creditsActive) return;
    const el = document.getElementById("ec-inner");
    if (!el) return;
    posY = getScrollPosition(el);
    el.style.transform = `translateX(-50%) translateY(${posY}px)`;
    rafId = requestAnimationFrame(tick);
  }

  rafId = requestAnimationFrame(tick);
}

function stopCredits() {
  if (!creditsActive) return;
  setCreditsActive(false);
  currentCreditsHtml = "";
  currentCreditsStartedAt = 0;
  if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
  document.getElementById("ec-overlay")?.remove();
}

// ── Socket ─────────────────────────────────────────────────────────────────

function initSocket() {
  game.socket.on(SOCKET_EVENT, ({ action, creditsHtml, startedAt }) => {
    if (action === "start") startCredits(creditsHtml, startedAt);
    if (action === "stop")  stopCredits();
  });
}

// ── Public API ─────────────────────────────────────────────────────────────

async function apiToggle() {
  if (!game.user.isGM) {
    ui.notifications.warn("End Credits: only the GM can start or stop the credits.");
    return;
  }

  const starting = !(creditsActive || game.settings.get(MODULE_ID, "endCreditsActive"));
  const action   = starting ? "start" : "stop";
  const creditsHtml = starting ? buildCreditsHTML() : "";
  const startedAt = starting ? Date.now() : 0;

  // Persist state so late-joining clients can catch up on their `ready` hook
  await game.settings.set(MODULE_ID, "endCreditsHtml", creditsHtml);
  await game.settings.set(MODULE_ID, "endCreditsStartedAt", startedAt);
  await game.settings.set(MODULE_ID, "endCreditsActive", starting);

  // Broadcast to all currently connected clients (they handle their own overlay)
  game.socket.emit(SOCKET_EVENT, { action, creditsHtml, startedAt });

  // GM handles their own overlay
  if (starting) startCredits(creditsHtml, startedAt);
  else          stopCredits();

  // GM handles music (Foundry syncs to everyone else automatically)
  if (starting) startMusic();
  else          stopMusic();
}

async function apiPrompt() {
  if (!game.user.isGM) {
    ui.notifications.warn("End Credits: only the GM can start or stop the credits.");
    return;
  }

  const running = creditsActive || game.settings.get(MODULE_ID, "endCreditsActive");
  const title = running ? "Stop End Credits?" : "Start End Credits?";
  const content = running
    ? "<p>Stop the scrolling end credits for all connected players?</p>"
    : "<p>Start the scrolling end credits for all connected players?</p>";

  if (foundry.applications?.api?.DialogV2) {
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title },
      content,
      yes: { label: running ? "Stop Credits" : "Start Credits", icon: running ? "fas fa-stop-circle" : "fas fa-film" },
      no: { label: "Cancel" },
    });
    if (confirmed) return apiToggle();
    return;
  }

  return new Promise((resolve) => {
    new Dialog({
      title,
      content,
      buttons: {
        confirm: {
          icon: running ? '<i class="fas fa-stop-circle"></i>' : '<i class="fas fa-film"></i>',
          label: running ? "Stop Credits" : "Start Credits",
          callback: async () => resolve(await apiToggle()),
        },
        cancel: {
          icon: '<i class="fas fa-times"></i>',
          label: "Cancel",
          callback: () => resolve(),
        },
      },
      default: "confirm",
      close: () => resolve(),
    }).render(true);
  });
}

function registerApi() {
  const module = game.modules.get(MODULE_ID);
  if (!module) return;
  module.api = {
    ...(module.api ?? {}),
    endCredits: {
      toggle: apiToggle,
      prompt: apiPrompt,
      start: async () => {
        if (!creditsActive) return apiToggle();
      },
      stop: async () => {
        if (creditsActive) return apiToggle();
      },
      isActive: () => creditsActive,
    },
    promptEndCredits: apiPrompt,
  };
}

// ── Init ───────────────────────────────────────────────────────────────────

Hooks.once("init", () => {
  // World settings — persisted so late-joiners know the current state
  const worldHidden = { scope: "world", config: false };
  const hiddenSettings = [
    ["endCreditsActive", { ...worldHidden, name: "End Credits Active", hint: "Internal end credits active state.", type: Boolean, default: false }],
    ["endCreditsPlaylistId", { ...worldHidden, name: "End Credits Playlist", hint: "Stored end credits playlist id.", type: String, default: "" }],
    ["endCreditsSoundId", { ...worldHidden, name: "End Credits Sound", hint: "Stored end credits sound id.", type: String, default: "" }],
    ["endCreditsHtml", { ...worldHidden, name: "End Credits HTML", hint: "Stored GM-generated end credits payload.", type: String, default: "" }],
    ["endCreditsStartedAt", { ...worldHidden, name: "End Credits Started At", hint: "Stored GM-generated end credits start timestamp.", type: Number, default: 0 }],
    ["endCreditsBackgroundImage", { ...worldHidden, name: "End Credits Background", hint: "Stored end credits background image or video.", type: String, default: "" }],
    ["endCreditsBgOpacity", { ...worldHidden, name: "End Credits Background Opacity", hint: "Stored end credits background opacity.", type: Number, default: 1.0 }],
  ];
  for (const [key, data] of hiddenSettings) {
    try {
      game.settings.register(MODULE_ID, key, data);
    } catch (error) {
      console.error(`PF2 Director | Failed to register end credits setting ${key}`, error);
    }
  }

  // Menu button — Music config (opens form)
  try {
    game.settings.registerMenu(MODULE_ID, "endCreditsMusicConfig", {
      name:       "End Credits Music",
      label:      "Configure Music",
      hint:       "Choose a playlist and track to play when the credits roll.",
      icon:       "fas fa-music",
      type:       EcMusicConfig,
      restricted: true,
    });
  } catch (error) {
    console.error("PF2 Director | Failed to register end credits menu endCreditsMusicConfig", error);
  }

  // Menu button — Background image config
  try {
    game.settings.registerMenu(MODULE_ID, "endCreditsImageConfig", {
      name:       "End Credits Background",
      label:      "Configure Background",
      hint:       "Select an image or video to display behind the credits. Leave blank for the default transparent overlay.",
      icon:       "fas fa-image",
      type:       EcImageConfig,
      restricted: true,
    });
  } catch (error) {
    console.error("PF2 Director | Failed to register end credits menu endCreditsImageConfig", error);
  }

  try {
    game.settings.register(MODULE_ID, "endCreditsMemoriamFolder", {
      name: "End Credits In Memoriam Folder",
      hint: "Optional actor folder name or slash-separated folder path to use for In Memoriam entries, for example Departed or NPCs/Departed.",
      scope: "world",
      config: true,
      type: String,
      default: "",
    });
  } catch (error) {
    console.error("PF2 Director | Failed to register end credits setting endCreditsMemoriamFolder", error);
  }

  // Menu button — Toggle credits (runs immediately, no form)
  // We register a dummy Application subclass; the real work is done in
  // renderSettingsConfig where we swap it for a live toggle button.
  try {
    game.settings.registerMenu(MODULE_ID, "endCreditsToggle", {
    name:       "End Credits",
    label:      "Start Credits",
    hint:       "Start or stop the scrolling end credits for all players.",
    icon:       "fas fa-film",
    type:       class EcToggleDummy extends FormApplication {
      render() { apiToggle(); }        // intercept — don't open a window
      async _updateObject() {}
    },
    restricted: true,
    });
  } catch (error) {
    console.error("PF2 Director | Failed to register end credits menu endCreditsToggle", error);
  }

  console.log("[End Credits] Initialized.");
});

Hooks.once("ready", () => {
  initSocket();

  // ── Late-join catch-up ────────────────────────────────────────────────────
  // If credits were already running when this client connected, start the
  // overlay now. Music is already playing server-side via Foundry's sync.
  if (game.settings.get(MODULE_ID, "endCreditsActive")) {
    console.log("[End Credits] Credits already active — starting overlay for late joiner.");
    startCredits(getStoredCreditsHtml(), getStoredCreditsStartedAt());
  } else {
    refreshSettingsToggleButton();
  }

  // Expose public API
  registerApi();

  console.log(`[End Credits] Ready. Macro: game.modules.get("pf2-david-music-control").api.endCredits.toggle();`);
});

// ── Settings panel — live toggle button ────────────────────────────────────
//
// renderSettingsConfig fires every time the settings window opens (or re-renders).
// We find the row Foundry generated for our end credits menu entry and
// swap its static label for one that reflects the current live state, so the
// GM always sees "Start Credits" or "Stop Credits" accurately.

Hooks.on("renderSettingsConfig", (_app, html) => {
  if (!game.user.isGM) return;

  const root = html instanceof HTMLElement ? html : html[0];
  const btn = root?.querySelector(`button[data-key="${MODULE_ID}.endCreditsToggle"]`);
  if (!btn) return;

  refreshSettingsToggleButton();

  // Re-check label after the click fires (apiToggle is async, so wait a tick)
  btn.addEventListener("click", () => setTimeout(refreshSettingsToggleButton, 50));
});

