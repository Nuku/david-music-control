# Foundry VTT - PF2 Director

![GitHub release (latest SemVer)](https://img.shields.io/github/v/release/Nuku/david-music-control)
![GitHub Releases](https://img.shields.io/github/downloads/Nuku/david-music-control/latest/pf2-david-music-control.zip)
![GitHub All Releases](https://img.shields.io/github/downloads/Nuku/david-music-control/pf2-david-music-control.zip?label=downloads)

PF2 Director is a Foundry VTT module for PF2e, SF2e, and DnD5E with encounter music control, scene presentation, party utilities, dramatic overlays, subsystem export tools, and cinematic end credits.

## Installation

Install from the manifest URL:

`https://raw.githubusercontent.com/Nuku/david-music-control/main/module.json`

Compatibility:

- Minimum Foundry version: `13`
- Verified Foundry version: `14`
- Supported game systems: **Pathfinder Second Edition (`pf2e`)**, **Starfinder Second Edition (`sf2e`)**, and **Dungeons & Dragons Fifth Edition (`dnd5e`)**
- Current release: **2.5.112**

SF2e uses the shared PF2e rules API for chat, rerolls, and party tools. Multi-target Taunt uses the active system's effect when available and a bundled effect otherwise, retaining the taunting creature as its origin. Roll retyping uses the active system's configured damage types, including homebrew types.

DnD5E worlds can use combat and scene music, victory playback and fireworks, token vision enhancements, dramatic health displays, end credits, and performance diagnostics. PF2e/SF2e party, chat, subsystem, creature sound, fire-light, and skill-check tools are system-specific and are only shown in those systems.

Optional integrations still require compatible versions of their dependencies. PF2e Subsystems declares support for both systems. The inspected PF2e Creature Sounds and Item Piles: PF2e releases declare only PF2e support; their ambience and merchant integrations are available only when those dependencies can be activated and used with your system.

## Feature Overview

PF2 Director currently includes:

- Combat music selection with per-token music, priorities, combat themes, encounter overrides, and a default combat playlist fallback
- Scene music lookup and manual scene-music playback from the playlists sidebar
- PF2e trait-based combat music rules
- Creature ambience using `pf2e-creature-sounds`, including audibility checks, distance and door muffling, and player-aware playback
- Victory music and Foundry V14 victory fireworks
- PF2e party utilities such as Full Rest, Cult tracking, and clustered party token art

When Item Piles is enabled, `Enable Item Piles Party Stash Merchant` is on by default. This adds a `Use Party Stash` button inside Item Piles merchant windows. Clicking it changes the merchant's `Shopping as` actor to the PF2e party actor, so purchases use the stash's inventory and funds while sales return items and funds to the stash. Install and activate `Item Piles: PF2e` alongside Item Piles for PF2e item pricing and currency support. The GM can disable this in PF2 Director settings.
- PF2e chat tools including roll retyping, villain-point rerolls, and explicit Half buttons for strikes, spells, impulses, and other cards that can roll damage
- Automatic Pacifying property-rune handling: the attacker is prompted to spend the reaction; if accepted, damaged creatures attempt a DC 20 Will save and, on failure, receive a 1-minute Pacified effect with a –2 penalty to attacks lacking the nonlethal trait
- Dramatic health display overlays with optional damage and healing sounds
- PF2e subsystem export and generation tools, including live creation support when `pf2e-subsystems` is installed
- Integrated end credits with configurable music, background media, and GM start or stop controls
- Optional Enhanced Vision, which calculates token vision from each of its four corners
- Optional custom art beneath PF2e's detected-token tint, fade, and concentric rings
- Optional Fire Glows: persistent fire damage adds a torch-animated light effect with 15 feet bright, 30 feet dim, and a 360-degree angle; losing all persistent fire damage removes it
- Automatic token level changes when elevation changes, preserving the current level in overlapping elevation ranges and asking players to confirm transitions
- Optional Randomly Locked Doors, with a configurable lock chance, per-scene opt-out, and Thievery or Athletics chat checks that open the door on success

### Enhanced Vision

When `Enhanced Vision` is enabled, tokens provide vision from four slightly inset corner positions rather than only from the center. Each corner still obeys wall line-of-sight, allowing an unobstructed corner to see around a wall without allowing the token to see through a wall it is touching. This costs additional perception calculations.

For troubleshooting, `Enhanced Vision Debug` draws the center, intended corners, wall collision points, and final viewpoints, and logs their coordinates in the browser console.

In the `Vision` settings, enable `Use Custom Image for Detected Tokens` and choose an image. PF2e's normal detection appearance remains in place; the selected image replaces the token art only while a detection filter is active.

Enable `Fire Glows` in the `Vision` settings to automatically add the light effect to PF2e and SF2e actors with persistent fire damage. Other persistent damage types do not trigger it. An active GM manages the effects, including existing actors and unlinked scene tokens when the option is enabled. Disabling the option removes its effects. The effect uses the systems' TokenLight rule, so removing it restores the token's normal light configuration.

## Music

### Combat Music

- Marks playlists as combat playlists and selects encounter music when combat starts
- Supports a default combat playlist when nothing else has higher priority
- Lets tokens define their own combat playlist, track, and priority
- Supports token rules such as HP or resource thresholds, turn-only tracks, and combat theme tokens
- Lets the GM set encounter music directly from the combat tracker
- Supports PF2e trait-based encounter music rules
- Pauses and restores non-combat ambience around combat
- Plays optional victory music after combat
- After victory music ends, automatically resumes the saved pre-combat ambience
- On Foundry V14+, can display colorful victory fireworks scaled from encounter difficulty

### Scene Music

- `Play Scene Music` can automatically look for music when a scene is activated
- A matching playlist by scene name is treated as a strong candidate, but the search continues through folders and other playlist options
- If multiple candidates are found, the GM gets a chooser
- If one candidate is found, it plays directly
- If no replacement is found, current music is left alone
- A manual `Play Scene Music` button is added to the playlists sidebar

### Creature Ambience

When `Enable Creature Ambience` is on:

- ambient creature noises are sourced from `pf2e-creature-sounds`
- audibility is checked to each player's nearest suitable token
- doors and distance reduce what each player hears
- the GM can enable debug logging and a local test override when no players are connected

## PF2e Tools

### Chat Tools

When enabled, PF2 Director adds several PF2e-specific chat actions:

- Roll retyping for eligible non-d20 chat cards, allowing typed damage or healing follow-up cards
- Half-damage buttons for PF2e cards that already expose a damage action, including strikes, spells, and impulses
- Half uses the same underlying PF2e damage action as the normal damage button, then rewrites the created damage card to half damage so traits and context carry over cleanly
- Villain-point reroll buttons on eligible d20 chat messages

### Cluster Party

PF2e party actors get a `Cluster Party` button in Token Configuration. It builds a combined crowd-style token image from party member token art, saves it in the world folder, and applies it to the party actor and token.

### Full Rest

When `Enable Full Rest` is on, PF2e party sheets gain a `Recover` button that:

- heals all party members to full HP
- restores all focus points
- removes the `Wounded` condition
- posts a chat summary and opens a rest report dialog

### At-Will Recharge

When `Enable At-Will Recharge` is on, PF2e items with `(at will)` in their name automatically restore their expended use immediately after activation. This applies to both innate spell uses and frequency-based actions.

### Villain Points

When `Enable Villain Points` is on:

- every time a PF2e character's hero or mythic point total drops, the module tracks that spend
- every configured number of tracked point spends grants the GM 1 villain point, defaulting to 2
- if the most recent 5 chat messages include a gap of 12 hours or more between consecutive messages, tracked point uses and villain points reset to 0
- the GM gets a villain-point reroll button on eligible d20 chat messages
- the GM gets a floating villain-point widget for manual adjustment
- the module can play an optional synchronized dread sound and overlay when villain points are gained or spent

### Cult System

When `Enable PF2e Cult System` is on, PF2e party sheets gain a `Cult` tab for tracking:

- cult name and level
- Fervor, Recruitment, and Mythic points
- mantles and activities
- phase notes and current event state
- cult level checks and related rolls

### Subsystem Export And Generation

PF2 Director includes subsystem tools for PF2e journals and GM prep:

- parses subsystem-style journal text into exportable subsystem JSON
- supports Influence, Research, and Infiltration style data
- can generate new subsystem content from a chosen level
- can download generated subsystem data as JSON
- can create live subsystem entries directly when `pf2e-subsystems` is installed and enabled

## Dramatic Health Display

The module includes a dramatic health overlay system that can:

- show large transient damage or healing panels when visible tokens lose or gain HP
- animate HP bars and deltas with configurable thresholds
- optionally show numbers or rely more on visual presentation
- play separate configurable audio for damage and healing

## Settings

The settings UI is grouped into sections for:

- Music
- PF2e Tools
- Villain Points
- Dramatic Health Display
- Vision
- Doors
- End Credits

Additional settings menus include:

- trait music rule configuration
- victory music configuration
- victory fireworks image configuration
- detected token image configuration
- villain point dread sound configuration
- dramatic health sound configuration
- end credits music configuration
- end credits background image or video configuration
- end credits In Memoriam folder override
- end credits start or stop control

## End Credits

The module includes integrated end credits tools for campaign finales and session wrap-ups.

GMs can configure:

- optional credits music
- optional background image or video
- background opacity
- In Memoriam source folder

Credits can then be:

- started or stopped from Module Settings
- prompted with a GM confirmation flow
- controlled by macro or integration code

Macro / API entry points:

```js
game.modules.get("pf2-david-music-control").api.endCredits.prompt();
game.modules.get("pf2-david-music-control").api.endCredits.toggle();
```

Victory fireworks macro / API entry points:

```js
game.modules.get("pf2-david-music-control").api.victoryFireworks.trigger();
game.modules.get("pf2-david-music-control").api.victoryFireworks.trigger({ intensity: 100 });
```

Calling `trigger()` with no arguments uses the current combat to derive intensity and party-centered burst anchors. If no combat is active, it falls back to intensity `60`.

If the legacy `end-credits` module was previously used, this module migrates its saved settings into the integrated end credits feature.

## How Combat Selection Works

When combat starts, the module determines the best music candidate using these broad rules:

- combat playlists begin at baseline priority
- the configured default playlist can override that baseline
- tokens can raise priority with their own assigned music
- encounter-level overrides can replace the normal selection entirely

If multiple candidates tie at the top, one is selected from the tied results.
