import { getSetting, MODULE_ID } from './settings.js';
import { getTokenMusic } from './token.js';

const VICTORY_FIREWORKS_SOCKET_TYPE = 'victoryFireworks';

function getModuleSocketEvent() {
	return `module.${MODULE_ID}`;
}

/* -------------------------------------------- */
/*  State                                       */
/* -------------------------------------------- */

let ambiencePaused = []; // kept for safety, no longer used for ambience
let pendingPostVictoryMusic = [];
let pendingVictoryResumeTimer = null;

function getCurrentMusic(combat) {
	return combat._combatMusic || combat.getFlag(MODULE_ID, 'currentMusic') || '';
}

/* -------------------------------------------- */
/*  Sound helpers                               */
/* -------------------------------------------- */

// Is this sound (PlaylistSound or Playlist) currently playing?
function isPlaying(sound) {
	if (sound.documentName === 'PlaylistSound') return sound.playing;
	return sound.sounds.contents.some((s) => s.playing);
}

// Is this sound currently paused (has a pausedTime)?
function isPaused(sound) {
	if (sound.documentName === 'PlaylistSound') return !sound.playing && sound.pausedTime != null;
	return sound.sounds.contents.some((s) => !s.playing && s.pausedTime != null);
}

// Start playing a sound. If it's paused, resume it. If it's already playing, do nothing.
async function playSound(sound) {
	if (sound.documentName === 'PlaylistSound') {
		if (sound.playing) return; // already playing
		if (isPaused(sound)) await sound.update({ playing: true }); // resume
		else await sound.parent.playSound(sound); // fresh start
	} else {
		if (isPlaying(sound)) return; // already playing
		// For a playlist, resume any paused sounds, or start fresh.
		const pausedSounds = sound.sounds.contents.filter((s) => isPaused(s));
		if (pausedSounds.length > 0) {
			for (const s of pausedSounds) await s.update({ playing: true });
		} else {
			await sound.playAll();
		}
	}
}

// Pause a sound. If it's not playing, do nothing.
async function pauseSound(sound) {
	if (sound.documentName === 'PlaylistSound') {
		if (!sound.playing) return;
		await sound.update({ playing: false, pausedTime: sound.sound?.currentTime ?? null });
	} else {
		for (const s of sound.sounds.contents.filter((s) => s.playing)) {
			await s.update({ playing: false, pausedTime: s.sound?.currentTime ?? null });
		}
	}
}

// Stop a sound completely (clears pausedTime).
async function stopSound(sound) {
	if (sound.documentName === 'PlaylistSound') {
		await sound.parent.stopSound(sound);
	} else {
		await sound.stopAll();
	}
}

/* -------------------------------------------- */
/*  Ambience                                    */
/* -------------------------------------------- */

function pauseAllMusic(combat) {
	const combatPlaylistIds = new Set(getCombatMusic().map((p) => p.id));
	const playing = game.playlists.playing
		.filter((p) => !combatPlaylistIds.has(p.id))
		.flatMap((p) => p.sounds.contents.filter((s) => s.playing));

	// Note exactly what was playing so we can restart it after combat.
	const noted = playing.map((s) => stringifyMusic(s));
	combat.setFlag(MODULE_ID, 'preCombatMusic', noted);

	for (const s of playing) s.update({ playing: false, pausedTime: s.sound?.currentTime ?? null });
}



/* -------------------------------------------- */
/*  Combat music tracking                       */
/* -------------------------------------------- */

export function setCombatMusic(sound, combat = game.combat, token) {
	if (combat) {
		combat.update({
			[`flags.${MODULE_ID}`]: {
				currentMusic: stringifyMusic(sound),
				token,
			},
		});
	}
}

/* -------------------------------------------- */
/*  Core: switch to a new track                 */
/* -------------------------------------------- */

// Switch combat music to `music`. Stops whatever was playing before (unless it's the same).
// If `pausePrevious` is true, pauses instead of stops (so it can be resumed later).
async function switchTo(combat, music, token, { pausePrevious = false } = {}) {
	const oldMusic = getCurrentMusic(combat);
	const newSound = parseMusic(music);
	if ('error' in newSound) {
		if (newSound.error === 'not found') ui.notifications.error(`${newSound.rgx[2] ? 'Track' : 'Playlist'} not found.`);
		if (newSound.error === 'invalid flag') ui.notifications.error('Bad configuration.');
		return;
	}

	// If already playing this exact music, do nothing.
	if (oldMusic === music && isPlaying(newSound)) return;

	// Stop or pause the previous music.
	if (oldMusic && oldMusic !== music) {
		const oldSound = parseMusic(oldMusic);
		if (!('error' in oldSound)) {
			if (pausePrevious) await pauseSound(oldSound);
			else await stopSound(oldSound);
		}
	}

	// Play the new music.
	await playSound(newSound);

	// Update tracking.
	combat._combatMusic = music;
	setCombatMusic(newSound, combat, token);
}

/* -------------------------------------------- */
/*  Turn music logic                            */
/* -------------------------------------------- */

export async function updateTurnMusic(combat, changes) {
	// Only fire on actual turn/round changes, not flag updates.
	if (changes && !('turn' in changes) && !('round' in changes)) return;
	if (!combat.started || getCombatMusic().length === 0) return;

	const combatantToken = combat.combatant?.token ?? null;

	// ── Step 1: Does the current combatant have active personal music? ──
	const turnMusic = combatantToken ? getTokenMusic(combatantToken) : null;
	if (turnMusic) {
		const wasInterrupted = combat.getFlag(MODULE_ID, 'encounterInterrupted');
		if (!wasInterrupted) {
			// Pause the encounter track so we can resume it later.
			const encounterMusic = getEncounterMusic(combat);
			if (encounterMusic) {
				const encounterSound = parseMusic(encounterMusic);
				if (!('error' in encounterSound)) await pauseSound(encounterSound);
				await combat.setFlag(MODULE_ID, 'encounterInterrupted', true);
				await combat.setFlag(MODULE_ID, 'pausedEncounterMusic', encounterMusic);
			}
		}
		await switchTo(combat, turnMusic, combatantToken.id);
		return;
	}

	// ── Step 2: Were we interrupted last turn? Resume the encounter track. ──
	const wasInterrupted = combat.getFlag(MODULE_ID, 'encounterInterrupted');
	if (wasInterrupted) {
		// Stop or pause the turn music based on pauseTrack setting.
		const currentMusic = getCurrentMusic(combat);
		if (currentMusic) {
			const currentSound = parseMusic(currentMusic);
			if (!('error' in currentSound)) {
				if (getSetting('pauseTrack')) await pauseSound(currentSound);
				else await stopSound(currentSound);
			}
		}
		// Resume the paused encounter track.
		const pausedEncounterMusic = combat.getFlag(MODULE_ID, 'pausedEncounterMusic');
		if (pausedEncounterMusic) {
			const encounterSound = parseMusic(pausedEncounterMusic);
			if (!('error' in encounterSound)) await playSound(encounterSound);
			combat._combatMusic = pausedEncounterMusic;
			setCombatMusic(parseMusic(pausedEncounterMusic), combat, '');
		}
		await combat.setFlag(MODULE_ID, 'encounterInterrupted', false);
		await combat.unsetFlag(MODULE_ID, 'pausedEncounterMusic');
		return;
	}

	// ── Step 3: Resolve and play the encounter track. ──
	const encounterMusic = getEncounterMusic(combat);
	if (!encounterMusic) return;
	// Pause the previous encounter track if pauseTrack is enabled, otherwise stop it.
	await switchTo(combat, encounterMusic, '', { pausePrevious: getSetting('pauseTrack') });
}

// Resolve what the encounter-wide music should be:
// Manual override > Combat Theme > Trait music > Generic playlist
function getEncounterMusic(combat) {
	// Manual override.
	const overrideMusic = combat.getFlag(MODULE_ID, 'overrideMusic');
	if (overrideMusic) return overrideMusic;

	// Combat Theme token (highest priority wins).
	const themeMap = new Map();
	for (const combatant of combat.combatants.contents) {
		if (!combatant.token) continue;
		const token = combatant.token;
		if (!token.getFlag(MODULE_ID, 'combatTheme')) continue;
		const music = getTokenMusic(token);
		if (!music) continue;
		themeMap.set({ token: token.id, music }, token.getFlag(MODULE_ID, 'priority') ?? 10);
	}
	if (themeMap.size > 0) {
		const highest = getHighestPriority(themeMap);
		return pick(highest).music;
	}

	// Trait-based music (PF2e).
	const traitRules = getSetting('traitRules') ?? [];
	if (traitRules.length > 0) {
		const hostileTraits = new Set();
		for (const combatant of combat.combatants.contents) {
			if (!combatant.token?.actor) continue;
			if (combatant.token.disposition === CONST.TOKEN_DISPOSITIONS.FRIENDLY) continue;
			for (const trait of (combatant.token.actor.system?.traits?.value ?? []))
				hostileTraits.add(trait.toLowerCase());
		}
		const matching = traitRules.filter((r) => r.trait && hostileTraits.has(r.trait.toLowerCase()) && r.music);
		if (matching.length > 0) {
			return matching.reduce((a, b) => b.priority > a.priority ? b : a).music;
		}
	}

	// Generic combat playlist.
	const base = getSetting('defaultPlaylist');
	const combatPlaylists = new Map(getCombatMusic().map((p) => [{ token: '', music: p.id }, +(p.id === base)]));
	for (const combatant of game.combat.combatants.contents) {
		if (!combatant.token) continue;
		const music = getTokenMusic(combatant.token);
		const priority = combatant.token.getFlag(MODULE_ID, 'priority') ?? 10;
		const token = combatant.token.id;
		if (music && combatant.token.getFlag(MODULE_ID, 'turnOnly') === false)
			combatPlaylists.set({ token, music }, priority);
	}
	const highest = getHighestPriority(combatPlaylists);
	if (!highest.length) return null;
	return pick(highest).music || null;
}

export function resolveEncounterMusic(combat) {
	return getEncounterMusic(combat);
}

/* -------------------------------------------- */
/*  Combat start / end                          */
/* -------------------------------------------- */

async function playCombatMusic(combat) {
	if (getCombatMusic().length === 0) return;
	if (getSetting('pauseAmbience')) await pauseAllMusic(combat);
	await updateTurnMusic(combat);
}

async function resumeSavedMusic(flags = []) {
	for (const flag of flags) {
		const sound = parseMusic(flag);
		if (!('error' in sound)) await playSound(sound);
	}
}

function clearPendingVictoryResume() {
	if (pendingVictoryResumeTimer) {
		window.clearInterval(pendingVictoryResumeTimer);
		pendingVictoryResumeTimer = null;
	}
	pendingPostVictoryMusic = [];
}

function watchVictoryMusic(sound, preCombatMusic) {
	clearPendingVictoryResume();
	pendingPostVictoryMusic = [...preCombatMusic];

	pendingVictoryResumeTimer = window.setInterval(async () => {
		if (isPlaying(sound)) return;
		clearPendingVictoryResume();
		await resumeSavedMusic(preCombatMusic);
	}, 1000);
}

async function resumePlaylists(combat) {
	const victoryMusic = pendingVictoryMusic;
	pendingVictoryMusic = null;
	triggerVictoryFireworks(combat);

	// Stop combat music.
	const currentMusic = getCurrentMusic(combat);
	if (currentMusic) {
		const sound = parseMusic(currentMusic);
		if (!('error' in sound)) await stopSound(sound);
	}
	combat._combatMusic = '';

	// Play victory music if set, otherwise resume pre-combat music.
	const preCombatMusic = combat.getFlag(MODULE_ID, 'preCombatMusic') ?? [];
	if (victoryMusic) {
		const sound = parseMusic(victoryMusic);
		if (!('error' in sound)) {
			await playSound(sound);
			watchVictoryMusic(sound, preCombatMusic);
		} else {
			await resumeSavedMusic(preCombatMusic);
		}
	} else {
		await resumeSavedMusic(preCombatMusic);
	}
}

function xpFromLevelDiff(diff) {
	if (diff <= -4) return 10;
	if (diff === -3) return 15;
	if (diff === -2) return 20;
	if (diff === -1) return 30;
	if (diff === 0) return 40;
	if (diff === 1) return 60;
	if (diff === 2) return 80;
	if (diff === 3) return 120;
	return 160; // +4 or more
}

function getVictoryXpPerPlayer(combat) {
	const playerCombatants = combat.combatants.contents.filter((c) => c.token?.disposition === CONST.TOKEN_DISPOSITIONS.FRIENDLY);
	const playerCount = Math.max(playerCombatants.length, 1);
	const partyLevel = playerCombatants.length > 0
		? Math.round(playerCombatants.reduce((sum, c) => sum + (c.actor?.level ?? 0), 0) / playerCombatants.length)
		: 1;

	const enemies = combat.combatants.contents.filter((c) =>
		c.token?.disposition !== CONST.TOKEN_DISPOSITIONS.FRIENDLY
	);

	let totalXP = 0;
	for (const enemy of enemies) {
		const level = enemy.actor?.level ?? partyLevel;
		totalXP += xpFromLevelDiff(level - partyLevel);
	}

	// The level-diff table gives XP per person for a 4-player party. Scale for other party sizes.
	return totalXP * (4 / playerCount);
}

function getVictoryMusic(combat) {
	const xpPerPlayer = getVictoryXpPerPlayer(combat);

	const generic = getSetting('victoryMusicGeneric');
	const trivial = getSetting('victoryMusicTrivial');
	const boss = getSetting('victoryMusicBoss');

	if (xpPerPlayer >= 120) return boss || generic || null;
	if (xpPerPlayer < 40) return trivial || generic || null;
	return generic || null;
}

function getVictoryFireworksIntensity(combat) {
	return Math.max(0, Math.min(100, getVictoryXpPerPlayer(combat)));
}

function clampVictoryFireworksIntensity(intensity) {
	return Math.max(0, Math.min(100, Number(intensity) || 0));
}

function getTokenCenter(tokenDocument) {
	const tokenObject = tokenDocument?.object;
	if (tokenObject?.center) return tokenObject.center;
	if (typeof tokenDocument?.x !== 'number' || typeof tokenDocument?.y !== 'number') return null;

	const size = canvas.dimensions?.size ?? 100;
	const width = (tokenDocument.width ?? 1) * size;
	const height = (tokenDocument.height ?? 1) * size;
	return {
		x: tokenDocument.x + width / 2,
		y: tokenDocument.y + height / 2,
	};
}

function getVictoryFireworksAnchors(combat) {
	const friendlyCenters = combat.combatants.contents
		.filter((combatant) => combatant.token?.disposition === CONST.TOKEN_DISPOSITIONS.FRIENDLY)
		.map((combatant) => getTokenCenter(combatant.token))
		.filter((center) => center && Number.isFinite(center.x) && Number.isFinite(center.y));

	if (friendlyCenters.length === 0) return [];

	const anchorCount = Math.max(3, Math.min(8, friendlyCenters.length * 2));
	const anchors = [];
	for (let i = 0; i < anchorCount; i++) {
		const base = pick(friendlyCenters);
		const spread = 40 + Math.random() * 70;
		const angle = Math.random() * Math.PI * 2;
		anchors.push({
			x: base.x + Math.cos(angle) * spread,
			y: base.y + Math.sin(angle) * spread,
		});
	}

	return anchors;
}

function triggerVictoryFireworks(combat) {
	if (!getSetting('fireworksOnVictory')) return;

	const intensity = getVictoryFireworksIntensity(combat);
	if (intensity <= 0) return;

	const anchors = getVictoryFireworksAnchors(combat);
	game.socket?.emit(getModuleSocketEvent(), { type: VICTORY_FIREWORKS_SOCKET_TYPE, intensity, anchors });
	playVictoryFireworks(intensity, anchors);
}

async function triggerManualVictoryFireworks({ intensity, combat = game.combat } = {}) {
	const resolvedIntensity = intensity == null
		? (combat ? getVictoryFireworksIntensity(combat) : 60)
		: clampVictoryFireworksIntensity(intensity);
	if (resolvedIntensity <= 0) return false;

	const anchors = combat ? getVictoryFireworksAnchors(combat) : [];
	game.socket?.emit(getModuleSocketEvent(), { type: VICTORY_FIREWORKS_SOCKET_TYPE, intensity: resolvedIntensity, anchors });
	playVictoryFireworks(resolvedIntensity, anchors);
	return true;
}

function playVictoryFireworks(intensity, anchors = []) {
	if (!canvas?.ready) return;

	const ParticleGenerator = foundry.canvas?.animation?.ParticleGenerator;
	if (!ParticleGenerator) return;
	const colors = [0xff5f6d, 0xffc371, 0x7bed9f, 0x70a1ff, 0xe056fd, 0xf9ca24];
	const customTexture = String(getSetting('victoryFireworksTexture') ?? '').trim();
	const texture = customTexture || 'ui/particles/snow.png';
	const durationScale = 1 + intensity / 100;

	const burstCount = Math.max(2, Math.ceil(intensity / 20));
	const particlesPerBurst = Math.max(36, Math.round(36 + intensity * 1.8));
	const burstDelay = Math.round(180 + intensity * 4);
	const sceneRect = canvas.dimensions?.sceneRect;
	if (!sceneRect) return;

	const generator = new ParticleGenerator({
		mode: 'effect',
		manual: true,
		container: canvas.primary,
		bounds: sceneRect,
		textures: [texture],
		blend: PIXI.BLEND_MODES.SCREEN,
		lifetime: [Math.round(1000 * durationScale), Math.round(1900 * durationScale)],
		fade: { in: 0.04, out: 0.5 },
		velocity: { speed: [140, 460], angle: [0, 360] },
		alpha: [0.75, 1.0],
		scale: [0.2, 0.65],
		rotation: { speed: [-180, 180], spread: Math.PI },
		onSpawn: (particle) => {
			particle.tint = colors[Math.floor(Math.random() * colors.length)];
		},
	});

	generator.start();

	for (let i = 0; i < burstCount; i++) {
		window.setTimeout(() => {
			const anchor = anchors.length > 0 ? pick(anchors) : null;
			const x = anchor?.x ?? (sceneRect.x + sceneRect.width * (0.15 + Math.random() * 0.7));
			const y = anchor?.y ?? (sceneRect.y + sceneRect.height * (0.08 + Math.random() * 0.42));
			generator.spawnParticles(particlesPerBurst, {
				area: { x, y, radius: [12, 36] },
			});
		}, i * burstDelay);
	}

	const totalDuration = burstCount * burstDelay + Math.round(2200 * durationScale);
	window.setTimeout(() => generator.stop(), totalDuration);
}

/* -------------------------------------------- */
/*  Utilities (exported for other modules)      */
/* -------------------------------------------- */

export function parseMusic(flag) {
	const rgx = /(\w+)\.?(\w+)?/.exec(flag);
	if (!rgx) return { error: 'invalid flag' };
	const playlist = game.playlists.get(rgx[1]),
		sound = playlist?.sounds.get(rgx[2]);
	return sound ?? playlist ?? { error: 'not found', rgx };
}

export function stringifyMusic(sound) {
	return (sound?.parent ? sound.parent.id + '.' + sound.id : sound?.id) ?? '';
}

export function getCombatMusic() {
	return game.playlists.contents.filter((p) => p.getFlag(MODULE_ID, 'combat'));
}

export function getHighestPriority(map) {
	const max = Math.max(...map.values());
	return [...map].filter(([p, v]) => v === max).map(([p, v]) => p);
}

export function pick(array) {
	return array[~~(Math.random() * array.length)];
}

// Legacy export — kept for compatibility with encounter.js / token.js callers.
export async function updateCombatMusic(combat, music, token) {
	await switchTo(combat, music, token);
}

export function setTokenConfig(token, resource, sounds, priority = 10, turnOnly = false, active = false) {
	sounds = (sounds ?? []).sort((a, b) => b[1] - a[1]);
	token.setFlag(MODULE_ID, {
		active,
		resource,
		priority,
		musicList: sounds.map(([sound, threshold]) => [stringifyMusic(sound), threshold]),
		turnOnly,
	});
}

window.CombatMusicMaster = {
	setCombatMusic,
	setTokenConfig,
};

let pendingVictoryMusic = null;

Hooks.once('setup', () => {
	if (game.user.isGM) {
		Hooks.on('combatStart', playCombatMusic);
		Hooks.on('updateCombat', updateTurnMusic);
		Hooks.on('preDeleteCombat', (combat) => {
			pendingVictoryMusic = getVictoryMusic(combat);
		});
		Hooks.on('deleteCombat', resumePlaylists);
	}
});

Hooks.once('ready', () => {
	const module = game.modules.get(MODULE_ID);
	if (module) {
		module.api = {
			...(module.api ?? {}),
			victoryFireworks: {
				trigger: triggerManualVictoryFireworks,
			},
		};
	}

	game.socket?.on(getModuleSocketEvent(), (data) => {
		if (data?.type !== VICTORY_FIREWORKS_SOCKET_TYPE) return;
		playVictoryFireworks(Number(data.intensity) || 0, Array.isArray(data.anchors) ? data.anchors : []);
	});
});
