import {
	parseMusic,
	resolveEncounterMusic,
	updateCombatMusic,
	setTokenConfig,
	stringifyMusic,
	getCombatMusic,
	getHighestPriority,
	pick,
} from './music-manager.js';
import { MODULE_ID, getSetting } from './settings.js';

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

/**
 * Token Music Configuration Application
 */
class TokenMusicConfig extends HandlebarsApplicationMixin(ApplicationV2) {
	static DEFAULT_OPTIONS = {
		id: 'token-music-config',
		tag: 'form',
		window: {
			contentClasses: ['standard-form', 'token-config'],
			icon: 'fa-solid fa-music',
			title: 'Token Combat Music Configuration',
		},
		form: {
			closeOnSubmit: true,
			handler: TokenMusicConfig.#saveSettings,
		},
		position: { width: 500, height: 'auto' },
	};

	static PARTS = {
		body: { template: 'modules/pf2-david-music-control/templates/music-section.hbs' },
		footer: { template: 'templates/generic/form-footer.hbs' },
	};

	constructor(token, options = {}) {
		super(options);
		this.token = token;
		this._preview = this._prepareData();
	}

	_prepareData() {
		const token = this.token;
		return {
			musicList: getEffectiveTokenMusicFlag(token, 'musicList') ?? [['', 100]],
			resource: getEffectiveTokenMusicFlag(token, 'resource'),
			priority: getEffectiveTokenMusicFlag(token, 'priority') ?? 10,
			active: getEffectiveTokenMusicFlag(token, 'active') ?? false,
			turnOnly: getEffectiveTokenMusicFlag(token, 'turnOnly') ?? false,
			combatTheme: getEffectiveTokenMusicFlag(token, 'combatTheme') ?? false,
		};
	}

	_prepareSubmitData() {
		const active = this.element.querySelector('input[name="music-active"]').checked;
		const priority = parseInt(this.element.querySelector('input[name="priority"]').value) || 10;
		const turnOnly = this.element.querySelector('input[name="turn-only"]').checked;
		const combatTheme = this.element.querySelector('input[name="combat-theme"]').checked;
		const resource = this.element.querySelector('select[name="tracked-resource"]').value;
		const musicList = this.#getTrackData();
		return { musicList, resource, active, priority, turnOnly, combatTheme };
	}

	_previewChanges(data) {
		this._preview = { ...this._prepareSubmitData(), ...data };
	}

	_prepareContext(_options) {
		const token = this.token;
		const data = this._preview;
		const musicList = data.musicList;
		const resource = data.resource;
		const trackedResource = resource
			? token.getBarAttribute?.('tracked-resource', {
					alternative: resource,
			  })
			: token.getBarAttribute('bar1');

		const trackSelection = musicList.map((music, index) => {
			const parsed = parseMusic(music[0]);
			const playlist = 'error' in parsed ? undefined : parsed?.parent ?? parsed;
			const track = playlist === parsed ? undefined : 'error' in parsed ? undefined : parsed;
			return {
				threshold: music[1],
				disabled: index === 0,
				playlistId: playlist?.id ?? '',
				trackId: track?.id ?? '',
			};
		});

		const usesTrackableAttributes = !foundry.utils.isEmpty(CONFIG.Actor.trackableAttributes);
		const actor = token.actor;
		const attributeSource =
			actor?.system instanceof foundry.abstract.DataModel && usesTrackableAttributes
				? actor.type
				: actor?.system;
		const TokenDocument = foundry.utils.getDocumentClass('Token');
		const attributes = TokenDocument.getTrackedAttributes(attributeSource);
		const barAttributes = TokenDocument.getTrackedAttributeChoices(attributes);
		const completeAttributes = barAttributes.filter((attr) => attr.group === 'Attribute Bars');

		return {
			trackedResource,
			trackSelection,
			completeAttributes,
			musicPriority: data.priority,
			musicActive: data.active,
			turnOnly: data.turnOnly,
			combatTheme: data.combatTheme,
			isDefault: false,
			buttons: [{ type: 'submit', icon: 'fa-solid fa-floppy-disk', label: 'SETTINGS.Save' }],
		};
	}

	_onRender(context, options) {
		super._onRender(context, options);
		this.#populatePlaylistOptions(context);
		this.setupEventListeners();
	}

	#updateTracksForPlaylist(playlistSelect, playlistId, selectedTrackId = '') {
		const trackSelect = playlistSelect.parentElement.nextElementSibling?.querySelector('select[name="track"]');
		if (!trackSelect) return;

		trackSelect.innerHTML = '<option value=""></option>';

		if (!playlistId) return;

		const playlist = game.playlists.get(playlistId);
		if (!playlist) return;

		playlist.sounds.contents.forEach((track) => {
			const option = document.createElement('option');
			option.value = track.id;
			option.textContent = track.name;
			option.selected = track.id === selectedTrackId;
			trackSelect.appendChild(option);
		});
	}

	#populatePlaylistOptions(context) {
		const combatPlaylists = getCombatMusic();
		const playlistSelects = this.element.querySelectorAll('select[name="playlist"]');

		playlistSelects.forEach((select, index) => {
			const trackSelection = context.trackSelection[index];
			if (!trackSelection) return;

			select.innerHTML = '<option value=""></option>';
			combatPlaylists.forEach((playlist) => {
				const option = document.createElement('option');
				option.value = playlist.id;
				option.textContent = playlist.name;
				option.selected = playlist.id === trackSelection.playlistId;
				select.appendChild(option);
			});

			if (trackSelection.playlistId) {
				this.#updateTracksForPlaylist(select, trackSelection.playlistId, trackSelection.trackId);
			}
		});
	}

	/* -------------------------------------------- */
	/*  Event Handlers                              */
	/* -------------------------------------------- */

	setupEventListeners() {
		// Add track button
		this.element.querySelector('[data-action="addTrack"]')?.addEventListener('click', (event) => {
			event.preventDefault();
			event.stopPropagation();
			this.#onAddTrack(event);
		});

		// Remove track buttons
		this.element.querySelectorAll('[data-action="removeTrack"]').forEach((button) => {
			button.addEventListener('click', (event) => {
				event.preventDefault();
				event.stopPropagation();
				this.#onRemoveTrack(event);
			});
		});

		// Playlist change handlers
		this.element.querySelectorAll('select[name="playlist"]').forEach((select) => {
			select.addEventListener('change', this.#onPlaylistChange.bind(this));
		});

		// Resource change handler
		this.element
			.querySelector('select[name=tracked-resource')
			.addEventListener('change', this.#onChangeBar.bind(this));
	}

	/**
	 * Handle changing the attribute bar in the drop-down selector to update the default current and max value
	 * @param {Event} event  The select input change event
	 */
	#onChangeBar(event) {
		const form = this.form;
		const attr = this.token.getBarAttribute('', { alternative: event.target.value });
		const barName = event.target.name;
		form.querySelector(`input[data-${barName}-value]`).value = attr !== null ? attr.value : '';
		form.querySelector(`input[data-${barName}-max]`).value = attr !== null && attr.type === 'bar' ? attr.max : '';
	}

	#onPlaylistChange(event) {
		this.#updateTracksForPlaylist(event.target, event.target.value);
	}

	#getTrackData() {
		const trackData = [];
		const trackSelections = this.element.querySelectorAll('fieldset.track-selection');

		trackSelections.forEach((el) => {
			const threshold = parseInt(el.querySelector('input[name="threshold"]').value) || 0;
			const playlistEl = el.querySelector('select[name="playlist"]');
			const trackEl = el.querySelector('select[name="track"]');

			const playlist = game.playlists.get(playlistEl.value);
			const track = playlist?.sounds.get(trackEl.value);

			trackData.push([stringifyMusic(track || playlist), threshold]);
		});

		return trackData;
	}

	async #onAddTrack(event) {
		event.preventDefault();
		const musicList = this.#getTrackData();
		const newThreshold = ~~(musicList.at(-1)[1] / 2);
		musicList.push(['', newThreshold]);
		this._previewChanges({ musicList });
		this.render(true);
	}

	async #onRemoveTrack(event) {
		event.preventDefault();
		const trackSelection = event.target.closest('.track-selection');
		const index = parseInt(trackSelection.dataset.index);

		const musicList = this.#getTrackData();

		// Remove track at index
		musicList.splice(index, 1);

		this._previewChanges({ musicList });
		this.render(true);
	}

	/**
	 * @this {TokenMusicConfig}
	 */
	static async #saveSettings(_event, _form, _formData) {
		const data = this._prepareSubmitData();
		await this.token.update({ [`flags.${MODULE_ID}`]: data });
	}
}

export function createOption(sound) {
	return `<option value="${sound ? sound.id : ''}" ${sound?.selected ? 'selected' : ''}> ${
		sound ? sound.name : ''
	}</option>`;
}

export function getEffectiveTokenMusicFlag(token, key) {
	const tokenValue = token?.getFlag?.(MODULE_ID, key);
	if (tokenValue !== undefined) return tokenValue;

	if (token?.actorLink) {
		const prototypeValue = token.actor?.prototypeToken?.getFlag?.(MODULE_ID, key);
		if (prototypeValue !== undefined) return prototypeValue;
	}

	return undefined;
}

export function getTokenHeaderButtons(sheet, buttons) {
	try {
		if (!game.user.isGM) return;
		buttons.unshift({
			label: 'Combat Music',
			class: 'configure-combat-music',
			icon: 'fas fa-music',
			onClick: () => new TokenMusicConfig(sheet.token).render(true),
		});
	} catch (error) {
		console.error('PF2 Director | Error adding actor sheet header buttons:', error);
	}
}

function resourceTracker(actor) {
	if (!game.combat?.started) return;
	const token = actor.token;
	if (!token) return;
	const combatant = token.combatant;
	if (!combatant) return;
	const combat = combatant.combat;

	// If this token is a Combat Theme token, re-evaluate which theme track should
	// be playing whenever their resource (e.g. HP) changes — even mid-turn.
	if (getEffectiveTokenMusicFlag(token, 'combatTheme') && !combat.getFlag(MODULE_ID, 'overrideMusic')) {
		const encounterMusic = resolveEncounterMusic(combat);
		if (!encounterMusic) return;

		if (combat.getFlag(MODULE_ID, 'encounterInterrupted')) {
			const pausedEncounterMusic = combat.getFlag(MODULE_ID, 'pausedEncounterMusic');
			if (encounterMusic !== pausedEncounterMusic) {
				combat.setFlag(MODULE_ID, 'pausedEncounterMusic', encounterMusic);
			}
			return;
		}

		const currentMusic = combat._combatMusic || combat.getFlag(MODULE_ID, 'currentMusic');
		if (encounterMusic !== currentMusic) updateCombatMusic(combat, encounterMusic, '');
		return;
	}

	// Original behaviour: update music if this token currently owns the combat music.
	const musicToken = combat.getFlag(MODULE_ID, 'token');
	if (!musicToken || musicToken !== token.id) return;
	if (combat.getFlag(MODULE_ID, 'token') !== token.id) return;
	const music = getTokenMusic(token);
	if (music) updateCombatMusic(combat, music);
}

export function getTokenMusic(token) {
	const active = getEffectiveTokenMusicFlag(token, 'active');
	if (!active) return;

	const attribute = token.actor?.system?.attributes?.hp ?? token.getBarAttribute('bar1');
	const musicList = getEffectiveTokenMusicFlag(token, 'musicList');
	if (!musicList) return;

	if (attribute.value > attribute.max) attribute.value = attribute.max;
	const attrThreshold = attribute === undefined || !attribute.max ? 100 : (100 * attribute.value) / attribute.max;

	for (let i = musicList.length; i > 0; i--) {
		const [music, threshold] = musicList[i - 1];
		if (attrThreshold <= threshold) {
			if (music === '') {
				const base = getSetting('defaultPlaylist');
				const combatPlaylists = new Map(
					getCombatMusic().map((p) => [{ token: '', music: p.id }, +(p.id === base)])
				);
				return pick(getHighestPriority(combatPlaylists)).music;
			}
			return music;
		}
	}
}

Hooks.once('setup', () => {
	if (game.user.isGM) {
		Hooks.on('updateActor', resourceTracker);
		Hooks.on('updateToken', (token) => resourceTracker(token.actor));
	}
});
Hooks.on('getHeaderControlsTokenApplication', getTokenHeaderButtons);
